# HoleLight AOD — 0.3.4

## V0.3.4 修复
- 重写通知应用列表读取：直接调用 PackageManager.getInstalledApplications(0) 枚举当前用户已安装应用。
- 不再依赖 Launcher 查询结果，不再使用 FLAG_INSTALLED 过滤，规避部分 HyperOS ROM 对 Launcher 查询/匹配标志的兼容问题。
- 保留 AndroidManifest.xml 中 QUERY_ALL_PACKAGES 声明。
- 应用列表为空时显示 PackageManager 读取异常类型；有结果时显示实际读取数量。
- 保留 V0.3.3 通知监听事件缓存、B 规则、应用单独开关、全选/全关闭、搜索和只看已开启功能。
- 保留 V0.3.1 摄像头定位算法。
- versionCode 9，versionName 0.3.4。

## 测试
安装 V0.3.4 后进入应用管理，确认已读取应用数量大于 0；搜索微信并开启，发送未清除通知测试图标；清除通知测试图标消失。

## 权限与限制
应用列表读取依赖清单中的 QUERY_ALL_PACKAGES。通知显示依赖用户手动授权 Notification Listener。项目使用无障碍覆盖层，不是系统签名原生 AOD。
