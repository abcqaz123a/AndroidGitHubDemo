
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.holelight.aod"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.holelight.aod"
        minSdk = 26
        targetSdk = 35
        versionCode = 23
        versionName = "0.6.3"
    }

    // Java 编译目标统一为 JVM 17
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Kotlin 编译目标统一为 JVM 17
    kotlinOptions {
        jvmTarget = "17"
    }
}
