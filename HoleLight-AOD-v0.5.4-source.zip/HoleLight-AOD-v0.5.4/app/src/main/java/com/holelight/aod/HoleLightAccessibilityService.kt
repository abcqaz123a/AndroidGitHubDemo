package com.holelight.aod

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class HoleLightAccessibilityService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var overlay: RingOverlayView? = null
    private var keyguard: KeyguardManager? = null
    private var power: PowerManager? = null
    private val main = Handler(Looper.getMainLooper())
    private val refreshTask = Runnable { refresh() }
    private var receiverRegistered = false
    private var attachRetryCount = 0

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // 关闭屏幕时不尝试向低功耗 AOD 层强行添加普通覆盖层。
                    // 通知包名仍保存在偏好设置中，点亮锁屏后会重新显示。
                    main.removeCallbacks(refreshTask)
                    removeOverlay()
                }
                Intent.ACTION_SCREEN_ON -> scheduleRefresh(180L)
                Intent.ACTION_USER_PRESENT -> scheduleRefresh(80L)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        power = getSystemService(Context.POWER_SERVICE) as PowerManager
        registerScreenReceiver()
        scheduleRefresh(0L)
    }

    private fun registerScreenReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(screenReceiver, filter)
            }
            receiverRegistered = true
        }
    }

    // 不读取窗口内容，不依赖高频无障碍事件。
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    private fun scheduleRefresh(delay: Long = 0L) {
        main.removeCallbacks(refreshTask)
        main.postDelayed(refreshTask, delay.coerceAtLeast(0L))
    }

    private fun attach(): Boolean {
        if (overlay?.isAttachedToWindow == true) return true
        // WindowManager 可能在服务重连后发生变化，重新获取句柄。
        if (wm == null) wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = RingOverlayView(this)
        @Suppress("DEPRECATION")
        val showWhenLockedFlag = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                showWhenLockedFlag,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        return try {
            wm?.addView(view, params)
            overlay = view
            attachRetryCount = 0
            view.refreshIcons()
            true
        } catch (_: Exception) {
            overlay = null
            false
        }
    }

    private fun removeOverlay() {
        val old = overlay ?: return
        overlay = null
        runCatching {
            if (old.isAttachedToWindow) wm?.removeViewImmediate(old)
        }
    }

    private fun refresh() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        if (!prefs.getBoolean("app_enabled", true)) {
            attachRetryCount = 0
            removeOverlay()
            return
        }

        val km = keyguard ?: run {
            keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguard
        } ?: return
        val isInteractive = power?.isInteractive ?: true
        val isLocked = km.isKeyguardLocked
        val previewEnabled = prefs.getBoolean("preview_enabled", false)
        val activePackages = prefs.getString("notification_packages", "").orEmpty()
            .split("|").filter { it.isNotBlank() }.distinct()

        // 普通覆盖层只能在屏幕点亮的锁屏界面显示；屏幕完全关闭时由系统 AOD 接管。
        val shouldShow = isInteractive && (previewEnabled || (isLocked && activePackages.isNotEmpty()))
        if (!shouldShow) {
            attachRetryCount = 0
            removeOverlay()
            return
        }

        if (overlay?.isAttachedToWindow != true) {
            overlay = null
            if (!attach()) {
                // 部分 HyperOS 时序下窗口服务/锁屏窗口尚未就绪，有限次数重试。
                if (attachRetryCount < 4) {
                    attachRetryCount++
                    scheduleRefresh(250L * attachRetryCount)
                }
                return
            }
        }
        attachRetryCount = 0
        overlay?.refreshIcons()
        overlay?.invalidate()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        main.removeCallbacksAndMessages(null)
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(screenReceiver) }
        receiverRegistered = false
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(screenReceiver) }
        receiverRegistered = false
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var instance: HoleLightAccessibilityService? = null
        fun requestRefresh(delay: Long = 0L) {
            instance?.scheduleRefresh(delay)
        }
    }
}
