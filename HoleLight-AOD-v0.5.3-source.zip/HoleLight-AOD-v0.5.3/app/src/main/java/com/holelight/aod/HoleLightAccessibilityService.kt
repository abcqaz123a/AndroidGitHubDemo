package com.holelight.aod

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class HoleLightAccessibilityService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var overlay: RingOverlayView? = null
    private var keyguard: KeyguardManager? = null
    private val main = Handler(Looper.getMainLooper())
    private val refreshTask = Runnable { refresh() }
    private var receiverRegistered = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            scheduleRefresh(120L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        registerScreenReceiver()
        scheduleRefresh(0L)
    }

    private fun registerScreenReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            else @Suppress("DEPRECATION") registerReceiver(screenReceiver, filter)
            receiverRegistered = true
        }
    }

    // 此服务不需要读取窗口内容，也不依赖高频无障碍事件；避免事件风暴导致覆盖层反复刷新。
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    private fun scheduleRefresh(delay: Long = 0L) {
        main.removeCallbacks(refreshTask)
        main.postDelayed(refreshTask, delay)
    }

    private fun attach() {
        if (overlay != null) return
        val view = RingOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            wm?.addView(view, params)
            overlay = view
            view.refreshIcons()
        } catch (_: Exception) {
            overlay = null
        }
    }

    private fun removeOverlay() {
        val old = overlay ?: return
        overlay = null
        runCatching { wm?.removeViewImmediate(old) }
    }

    private fun refresh() {
        val km = keyguard ?: return
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        // 总开关关闭时，无论预览状态或通知状态如何，都立即移除覆盖层。
        if (!prefs.getBoolean("app_enabled", true)) {
            removeOverlay()
            return
        }
        val previewEnabled = prefs.getBoolean("preview_enabled", false)
        val activePackages = prefs.getString("notification_packages", "").orEmpty()
            .split("|").filter { it.isNotBlank() }.distinct()
        val shouldShow = previewEnabled || (km.isKeyguardLocked && activePackages.isNotEmpty())
        if (!shouldShow) {
            removeOverlay()
            return
        }
        if (overlay == null) attach()
        overlay?.refreshIcons()
        overlay?.invalidate()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(screenReceiver) }
        receiverRegistered = false
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(screenReceiver) }
        receiverRegistered = false
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var instance: HoleLightAccessibilityService? = null
        fun requestRefresh() { instance?.scheduleRefresh(80L) }
    }
}
