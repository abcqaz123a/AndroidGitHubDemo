package com.holelight.aod

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.app.SearchManager
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("holelight", MODE_PRIVATE) }
    private lateinit var page: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var previewButton: TextView
    private var currentPage = "home"
    private val ioExecutor = Executors.newFixedThreadPool(2)
    private val uiHandler = Handler(Looper.getMainLooper())

    private val bg = Color.rgb(10, 13, 17)
    private val panel = Color.rgb(21, 27, 33)
    private val panel2 = Color.rgb(27, 35, 42)
    private val accent = Color.rgb(0, 205, 174)
    private val mainText = Color.rgb(239, 245, 247)
    private val muted = Color.rgb(145, 160, 169)
    private val line = Color.rgb(42, 54, 62)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 10, 13)
        window.navigationBarColor = Color.rgb(7, 10, 13)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        window.decorView.systemUiVisibility = 0

        val host = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false; setBackgroundColor(bg) }
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(page, ViewGroup.LayoutParams(-1, -2))
        host.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(host)
        if (Build.VERSION.SDK_INT >= 30) {
            host.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                v.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
            host.requestApplyInsets()
        } else host.setPadding(0, dp(24), 0, dp(24))
        showHome()
    }

    @Deprecated("Use system back navigation")
    override fun onBackPressed() {
        when (currentPage) {
            "home" -> super.onBackPressed()
            "menu" -> showHome()
            else -> showMenu()
        }
    }

    private fun showHome() {
        currentPage = "home"
        page.removeAllViews()
        header("HoleLight", "RGB 通知圆环", false)

        // 软件总开关：仅控制 HoleLight 覆盖层，不修改系统无障碍授权。
        val masterCard = card().apply { setPadding(dp(16), dp(12), dp(16), dp(12)) }
        val masterRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val masterText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        masterText.addView(label("软件总开关", 16f, mainText, true))
        masterText.addView(label("关闭后立即隐藏圆环与通知图标", 11f, muted).apply { setPadding(0, dp(3), 0, 0) })
        masterRow.addView(masterText, LinearLayout.LayoutParams(0, -2, 1f))
        val masterSwitch = Switch(this).apply {
            showText = false
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            trackTintList = android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accent, line)
            )
            isChecked = prefs.getBoolean(KEY_APP_ENABLED, true)
            contentDescription = "HoleLight 软件总开关"
            setOnCheckedChangeListener { _, enabled ->
                prefs.edit()
                    .putBoolean(KEY_APP_ENABLED, enabled)
                    .putBoolean(KEY_PREVIEW_ENABLED, enabled)
                    .apply()
                if (::previewButton.isInitialized) updatePreviewButton()
                HoleLightAccessibilityService.requestRefresh()
                if (!enabled) Toast.makeText(this@MainActivity, "HoleLight 已关闭", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this@MainActivity, "HoleLight 已启用", Toast.LENGTH_SHORT).show()
            }
        }
        masterRow.addView(masterSwitch)
        masterCard.addView(masterRow)
        page.addView(masterCard, match().bottom(14))

        val preview = card().apply { setPadding(dp(16), dp(14), dp(16), dp(14)) }
        rowIn(preview) {
            addView(label("◉", 34f, accent, true), LinearLayout.LayoutParams(dp(48), dp(48)))
            column {
                label("圆环样式", 17f, mainText, true)
                label("选择息屏通知灯的视觉效果", 12f, muted)
            }
        }
        val styles = listOf("静态彩虹", "流动彩虹", "呼吸渐变", "脉冲光环")
        val speedWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, styles)
            setSelection(prefs.getInt(RingOverlayView.KEY_STYLE, RingOverlayView.STYLE_STATIC).coerceIn(0, styles.lastIndex))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    prefs.edit().putInt(RingOverlayView.KEY_STYLE, position).apply()
                    speedWrap.visibility = if (position == RingOverlayView.STYLE_STATIC) View.GONE else View.VISIBLE
                    HoleLightAccessibilityService.requestRefresh()
                }
            }
        }
        preview.addView(spinner, match().top(12))
        addSeek(speedWrap, "动画速率", RingOverlayView.KEY_SPEED, 1, 10, RingOverlayView.DEFAULT_SPEED, "级")
        preview.addView(speedWrap, match().top(4))
        speedWrap.visibility = if (prefs.getInt(RingOverlayView.KEY_STYLE, 0) == 0) View.GONE else View.VISIBLE
        previewButton = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent); background = rounded(panel2, 12)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setOnClickListener {
                if (!prefs.getBoolean(KEY_APP_ENABLED, true)) return@setOnClickListener
                val enabled = !prefs.getBoolean(KEY_PREVIEW_ENABLED, true)
                prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, enabled).apply()
                updatePreviewButton(); HoleLightAccessibilityService.requestRefresh()
            }
        }
        preview.addView(previewButton, match().top(12))
        updatePreviewButton()
        page.addView(preview, match().bottom(14))

        actionButton("保存样式设置", true) {
            prefs.edit().putInt(RingOverlayView.KEY_STYLE, spinner.selectedItemPosition)
                .putInt(RingOverlayView.KEY_SPEED, prefs.getInt(RingOverlayView.KEY_SPEED, RingOverlayView.DEFAULT_SPEED)).commit()
            HoleLightAccessibilityService.requestRefresh()
            Toast.makeText(this, "圆环样式已保存", Toast.LENGTH_SHORT).show()
        }
        actionButton("恢复默认设置", false) { resetSettings() }
        menuEntry("更多设置", "圆环校准 · 图标布局 · 应用与权限", "☰") { showMenu() }
        label("HOLELIGHT  ·  0.5.2", 11f, muted).apply { gravity = Gravity.CENTER }.also { page.addView(it, match().top(16)) }
    }

    private fun showMenu() {
        currentPage = "menu"; page.removeAllViews()
        header("更多设置", "校准显示效果与管理权限", true)
        menuEntry("圆环校准", "摄像头对准、直径、亮度和位置", "◎") { showCalibration() }
        menuEntry("通知图标布局", "图标大小、间距与显示排列", "▦") { showIconSettings() }
        menuEntry("通知应用列表", "选择允许显示通知图标的应用", "▤") { showApps() }
        menuEntry("无障碍显示服务", "检查并开启圆环显示服务", "◉") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        menuEntry("通知读取权限", "管理通知监听权限", "♧") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        menuEntry("系统显示设置", "打开息屏显示（AOD）设置", "☼") { openAodSettings() }
        menuEntry("关于 HoleLight", "版本信息、隐私与兼容性说明", "ⓘ") { showAbout() }
    }

    private fun showCalibration() {
        currentPage = "calibration"; page.removeAllViews()
        header("圆环校准", "调整圆环与前置摄像头的位置", true)
        val box = card().apply { setPadding(dp(16), dp(12), dp(16), dp(8)) }
        val auto = CheckBox(this).apply {
            text = "自动对准前置摄像头"; textSize = 14f; setTextColor(mainText)
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
            isChecked = prefs.getBoolean(RingOverlayView.KEY_AUTO_CAMERA, true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(RingOverlayView.KEY_AUTO_CAMERA, checked).apply(); HoleLightAccessibilityService.requestRefresh() }
        }
        box.addView(auto)
        addSeek(box, "圆环直径", RingOverlayView.KEY_DIAMETER, 24, 180, RingOverlayView.DEFAULT_DIAMETER, " dp")
        addSeek(box, "圆环亮度", RingOverlayView.KEY_BRIGHTNESS, 20, 100, RingOverlayView.DEFAULT_BRIGHTNESS, "%")
        addSeek(box, "水平位置", RingOverlayView.KEY_X_OFFSET, -300, 300, 0, " dp")
        addSeek(box, "垂直位置", RingOverlayView.KEY_Y_POSITION, -200, 400, RingOverlayView.DEFAULT_Y_POSITION, " dp")
        page.addView(box, match().bottom(14))
        actionButton("保存校准参数", true) { saveSettings() }
    }

    private fun showIconSettings() {
        currentPage = "icons"; page.removeAllViews()
        header("通知图标布局", "调整圆环下方应用图标的显示", true)
        val box = card().apply { setPadding(dp(16), dp(12), dp(16), dp(8)) }
        addSeek(box, "图标大小", RingOverlayView.KEY_ICON_SIZE, 60, 140, RingOverlayView.DEFAULT_ICON_SIZE, "%")
        addSeek(box, "图标间距", RingOverlayView.KEY_ICON_GAP, 2, 20, RingOverlayView.DEFAULT_ICON_GAP, " dp")
        page.addView(box, match().bottom(14))
        actionButton("保存图标设置", true) { saveSettings() }
    }

    private data class AppRow(
        val info: ApplicationInfo,
        val name: String,
        val searchName: String
    )

    private fun showApps() {
        currentPage = "apps"
        page.removeAllViews()
        header("通知应用", "选择允许显示通知图标的应用", true)

        val summary = label("正在读取应用列表…", 13f, accent, true)
        val progress = ProgressBar(this).apply { isIndeterminate = true }
        val search = EditText(this).apply {
            hint = "搜索应用名称"; setSingleLine(true); textSize = 14f
            setTextColor(mainText); setHintTextColor(muted); background = rounded(panel, 10)
            setPadding(dp(14), dp(10), dp(14), dp(10)); isEnabled = false
        }
        val onlyOn = CheckBox(this).apply {
            text = "只显示已开启"; textSize = 13f; setTextColor(mainText)
            buttonTintList = android.content.res.ColorStateList.valueOf(accent); isEnabled = false
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val list = ListView(this).apply {
            divider = null; dividerHeight = 0; cacheColorHint = Color.TRANSPARENT
            setBackgroundColor(bg); isVerticalScrollBarEnabled = true
        }
        page.addView(summary, match().bottom(8))
        page.addView(progress, LinearLayout.LayoutParams(-1, dp(42)))
        page.addView(search, match().bottom(6))
        page.addView(onlyOn, match().bottom(6))
        actions.addView(smallAction("全选") {}, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(smallAction("全关闭") {}, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8) })
        page.addView(actions, match().bottom(8))
        val listHeight = (resources.displayMetrics.heightPixels * 0.52f).toInt().coerceAtLeast(dp(260))
        page.addView(list, LinearLayout.LayoutParams(-1, listHeight))
        list.setOnTouchListener { v, _ -> v.parent.requestDisallowInterceptTouchEvent(true); false }

        val allowedKey = "allowed_notification_packages"
        val knownKey = "known_app_packages"
        val apps = mutableListOf<AppRow>()
        val filtered = mutableListOf<AppRow>()
        val selectedPackages = (prefs.getStringSet(allowedKey, emptySet()) ?: emptySet()).toMutableSet()
        val iconCache = ConcurrentHashMap<String, Drawable>()
        val iconLoading = ConcurrentHashMap.newKeySet<String>()
        var adapter: BaseAdapter? = null
        var query = ""
        var onlyEnabled = false

        fun persistSelection() {
            prefs.edit().putStringSet(allowedKey, HashSet(selectedPackages)).apply()
            summary.text = "已启用 ${selectedPackages.size} / ${apps.size} 个应用"
        }
        fun applyFilter() {
            filtered.clear()
            filtered.addAll(apps.filter { app ->
                (query.isEmpty() || app.searchName.contains(query) || app.info.packageName.contains(query)) &&
                    (!onlyEnabled || selectedPackages.contains(app.info.packageName))
            })
            adapter?.notifyDataSetChanged()
            summary.text = "已启用 ${selectedPackages.size} / ${apps.size} 个应用 · 当前显示 ${filtered.size} 个"
        }

        adapter = object : BaseAdapter() {
            override fun getCount() = filtered.size
            override fun getItem(position: Int) = filtered[position]
            override fun getItemId(position: Int) = filtered[position].info.packageName.hashCode().toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row: LinearLayout
                val image: ImageView
                val check: CheckBox
                if (convertView == null) {
                    row = LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                        setPadding(dp(10), dp(6), dp(10), dp(6)); background = rounded(panel, 10)
                    }
                    image = ImageView(this@MainActivity)
                    row.addView(image, LinearLayout.LayoutParams(dp(38), dp(38)))
                    check = CheckBox(this@MainActivity).apply {
                        textSize = 14f; setTextColor(mainText)
                        buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                    }
                    row.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
                    row.tag = arrayOf(image, check)
                } else {
                    row = convertView as LinearLayout
                    val views = row.tag as Array<*>
                    image = views[0] as ImageView
                    check = views[1] as CheckBox
                }
                val app = getItem(position)
                val pkg = app.info.packageName
                image.tag = pkg
                image.setImageDrawable(iconCache[pkg])
                if (!iconCache.containsKey(pkg) && iconLoading.add(pkg)) {
                    ioExecutor.execute {
                        val drawable = runCatching { packageManager.getApplicationIcon(app.info) }.getOrNull()
                        if (drawable != null) iconCache[pkg] = drawable
                        iconLoading.remove(pkg)
                        uiHandler.post {
                            if (currentPage == "apps" && image.tag == pkg && drawable != null) {
                                image.setImageDrawable(drawable)
                            }
                        }
                    }
                }
                check.setOnCheckedChangeListener(null)
                check.text = app.name
                check.isChecked = selectedPackages.contains(pkg)
                check.setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) selectedPackages.add(pkg) else selectedPackages.remove(pkg)
                    persistSelection()
                    HoleLightNotificationListener.refreshFromSystem()
                    if (onlyEnabled && !isChecked) applyFilter()
                }
                row.setOnClickListener { check.isChecked = !check.isChecked }
                return row
            }
        }
        list.adapter = adapter

        val selectAll = actions.getChildAt(0) as TextView
        val clearAll = actions.getChildAt(1) as TextView
        selectAll.setOnClickListener {
            selectedPackages.clear(); selectedPackages.addAll(apps.map { it.info.packageName })
            persistSelection(); applyFilter(); HoleLightNotificationListener.refreshFromSystem()
        }
        clearAll.setOnClickListener {
            selectedPackages.clear(); persistSelection(); applyFilter()
            HoleLightNotificationListener.refreshFromSystem()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                query = s?.toString()?.trim()?.lowercase().orEmpty(); applyFilter()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        onlyOn.setOnCheckedChangeListener { _, checked -> onlyEnabled = checked; applyFilter() }

        // PackageManager 查询、应用名称解析和排序都放到工作线程，避免进入页面时阻塞主线程。
        ioExecutor.execute {
            val loaded = runCatching {
                @Suppress("DEPRECATION")
                packageManager.getInstalledApplications(0)
                    .asSequence()
                    .filter { it.packageName != packageName }
                    .map { info ->
                        val name = runCatching { packageManager.getApplicationLabel(info).toString() }
                            .getOrDefault(info.packageName)
                        AppRow(info, name, (name + " " + info.packageName).lowercase())
                    }
                    .sortedBy { it.searchName }
                    .toList()
            }.getOrDefault(emptyList())

            uiHandler.post {
                if (isFinishing || currentPage != "apps") return@post
                progress.visibility = View.GONE
                apps.clear(); apps.addAll(loaded)
                val installed = apps.map { it.info.packageName }.toSet()
                val known = (prefs.getStringSet(knownKey, emptySet()) ?: emptySet()).toMutableSet()
                if (!prefs.contains(allowedKey)) selectedPackages.addAll(installed)
                else if (prefs.contains(knownKey)) selectedPackages.addAll(installed - known)
                selectedPackages.retainAll(installed)
                prefs.edit().putStringSet(allowedKey, HashSet(selectedPackages))
                    .putStringSet(knownKey, HashSet(installed)).apply()
                search.isEnabled = true; onlyOn.isEnabled = true
                persistSelection(); applyFilter()
                if (loaded.isEmpty()) summary.text = "未读取到应用，请检查系统应用可见性设置"
            }
        }
    }

    private fun openAodSettings() {
        // 小米不同系统版本的息屏设置入口并非统一公开 API，按可用入口逐一尝试。
        val vendorActions = listOf(
            "miui.intent.action.AOD_SETTINGS",
            "com.android.settings.action.AOD_SETTINGS"
        )
        for (action in vendorActions) {
            try {
                startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (_: Exception) { }
        }
        // Android 设置搜索可用时，优先把用户带到“息屏显示”搜索。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val searchIntent = Intent(Settings.ACTION_APP_SEARCH_SETTINGS).apply {
                    putExtra(SearchManager.QUERY, "息屏显示")
                }
                startActivity(searchIntent)
                Toast.makeText(this, "请在设置搜索结果中选择「息屏显示」", Toast.LENGTH_LONG).show()
                return
            } catch (_: Exception) { }
        }
        // 最后回退到显示设置，并明确告知手动路径，避免假装已直达 AOD。
        try {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
            Toast.makeText(this, "请进入「个性化 / 息屏显示」", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "请在系统设置中搜索「息屏显示」", Toast.LENGTH_LONG).show()
        }
    }

    private fun showAbout() {
        currentPage = "about"; page.removeAllViews(); header("关于", "HoleLight RGB 通知圆环", true)
        val box = card().apply { setPadding(dp(16), dp(16), dp(16), dp(16)) }
        box.addView(label("版本 0.5.2", 18f, mainText, true))
        box.addView(label("圆环围绕前置摄像头显示；通知图标仅显示已允许应用中仍未清除的通知。", 14f, muted).apply { setPadding(0, dp(10), 0, 0) })
        box.addView(label("隐私说明", 15f, accent, true).apply { setPadding(0, dp(18), 0, dp(5)) })
        box.addView(label("应用不读取通知正文，不上传通知数据。应用筛选与通知状态保存在本机。", 13f, muted))
        box.addView(label("兼容性说明", 15f, accent, true).apply { setPadding(0, dp(18), 0, dp(5)) })
        box.addView(label("当前采用无障碍覆盖层方案，并非小米系统签名的原生 AOD。HyperOS 可能在真正低功耗息屏状态隐藏第三方覆盖层。", 13f, muted))
        page.addView(box, match())
    }

    private fun header(title: String, subtitle: String, back: Boolean) {
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        if (back) top.addView(TextView(this).apply {
            text = "‹"; textSize = 34f; setTextColor(accent); gravity = Gravity.CENTER
            setOnClickListener { onBackPressed() }
        }, LinearLayout.LayoutParams(dp(42), dp(48)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 26f, mainText, true)); texts.addView(label(subtitle, 12f, muted).apply { setPadding(0, dp(3), 0, 0) })
        top.addView(texts, LinearLayout.LayoutParams(0, -2, 1f)); page.addView(top, match().bottom(20))
    }

    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(panel, 16) }
    private fun rowIn(parent: LinearLayout, content: LinearLayout.() -> Unit) { val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; content() }; parent.addView(r, match()) }
    private fun LinearLayout.column(content: LinearLayout.() -> Unit) { val c = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; content() }; addView(c, LinearLayout.LayoutParams(0, -2, 1f)) }

    private fun menuEntry(title: String, sub: String, glyph: String, action: () -> Unit) {
        val item = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(panel, 14); isClickable = true; isFocusable = true; setOnClickListener { action() } }
        item.addView(TextView(this).apply { text = glyph; textSize = 23f; setTextColor(accent); gravity = Gravity.CENTER; background = rounded(panel2, 12) }, LinearLayout.LayoutParams(dp(46), dp(46)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        names.addView(label(title, 15f, mainText, true)); names.addView(label(sub, 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
        item.addView(names, LinearLayout.LayoutParams(0, -2, 1f)); item.addView(label("›", 24f, muted)); page.addView(item, match().bottom(9))
    }

    private fun actionButton(text: String, primary: Boolean, action: () -> Unit) {
        val b = TextView(this).apply { this.text = text; gravity = Gravity.CENTER; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (primary) Color.rgb(4, 20, 19) else mainText); background = rounded(if (primary) accent else panel2, 12); setPadding(dp(14), dp(14), dp(14), dp(14)); setOnClickListener { action() } }
        page.addView(b, match().bottom(9))
    }
    private fun smallAction(text: String, action: () -> Unit): View = TextView(this).apply { this.text = text; gravity = Gravity.CENTER; textSize = 13f; setTextColor(accent); background = rounded(panel2, 10); setOnClickListener { action() } }

    private fun addSeek(parent: LinearLayout, title: String, key: String, min: Int, max: Int, default: Int, suffix: String) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(5)) }
        val text = label("", 13f, mainText)
        val seek = SeekBar(this).apply { this.max = max - min; progressTintList = android.content.res.ColorStateList.valueOf(accent); thumbTintList = android.content.res.ColorStateList.valueOf(accent); progressBackgroundTintList = android.content.res.ColorStateList.valueOf(line) }
        val initial = prefs.getInt(key, default).coerceIn(min, max)
        fun update(value: Int) { text.text = "$title     $value$suffix" }
        seek.progress = initial - min; update(initial)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) { val value = progress + min; update(value); prefs.edit().putInt(key, value).apply(); if (fromUser) HoleLightAccessibilityService.requestRefresh() }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        wrap.addView(text); wrap.addView(seek, LinearLayout.LayoutParams(-1, dp(34))); parent.addView(wrap, match())
    }

    private fun saveSettings() { prefs.edit().commit(); HoleLightAccessibilityService.requestRefresh(); Toast.makeText(this, "设置已保存", Toast.LENGTH_SHORT).show() }
    private fun resetSettings() {
        prefs.edit().putInt(RingOverlayView.KEY_STYLE, RingOverlayView.STYLE_STATIC).putInt(RingOverlayView.KEY_SPEED, RingOverlayView.DEFAULT_SPEED)
            .putInt(RingOverlayView.KEY_DIAMETER, RingOverlayView.DEFAULT_DIAMETER).putInt(RingOverlayView.KEY_BRIGHTNESS, RingOverlayView.DEFAULT_BRIGHTNESS)
            .putInt(RingOverlayView.KEY_X_OFFSET, 0).putInt(RingOverlayView.KEY_Y_POSITION, RingOverlayView.DEFAULT_Y_POSITION)
            .putBoolean(RingOverlayView.KEY_AUTO_CAMERA, true).putInt(RingOverlayView.KEY_ICON_SIZE, RingOverlayView.DEFAULT_ICON_SIZE)
            .putInt(RingOverlayView.KEY_ICON_GAP, RingOverlayView.DEFAULT_ICON_GAP).apply()
        showHome(); HoleLightAccessibilityService.requestRefresh(); Toast.makeText(this, "已恢复默认设置", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        ioExecutor.shutdownNow()
        uiHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (prefs.getBoolean(KEY_APP_ENABLED, true)) prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, true).apply()
        if (::previewButton.isInitialized && currentPage == "home") updatePreviewButton()
        HoleLightAccessibilityService.requestRefresh()
    }
    override fun onStop() { prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, false).apply(); HoleLightAccessibilityService.requestRefresh(); super.onStop() }
    private fun updatePreviewButton() {
        if (::previewButton.isInitialized) {
            val appEnabled = prefs.getBoolean(KEY_APP_ENABLED, true)
            previewButton.isEnabled = appEnabled
            previewButton.alpha = if (appEnabled) 1f else 0.45f
            previewButton.text = when {
                !appEnabled -> "软件总开关已关闭"
                prefs.getBoolean(KEY_PREVIEW_ENABLED, true) -> "●  预览已开启   ·   点击隐藏"
                else -> "○  预览已关闭   ·   点击显示"
            }
        }
    }
    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply { text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun LinearLayout.LayoutParams.bottom(v: Int) = apply { bottomMargin = dp(v) }
    private fun LinearLayout.LayoutParams.top(v: Int) = apply { topMargin = dp(v) }

    companion object {
        private const val KEY_PREVIEW_ENABLED = "preview_enabled"
        private const val KEY_APP_ENABLED = "app_enabled"
    }
}
