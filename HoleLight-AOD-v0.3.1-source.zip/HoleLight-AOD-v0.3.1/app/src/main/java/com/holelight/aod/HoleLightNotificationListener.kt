package com.holelight.aod

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class HoleLightNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        publishActive()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        publishActive()
    }

    private fun publishActive() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        val allowed = prefs.getStringSet(KEY_ALLOWED_PACKAGES, null)?.toSet()
        val packages = activeNotifications
            ?.asSequence()
            // 常驻/持续通知（例如 VPN、音乐播放、前台服务）不显示在圆环上
            ?.filter { !it.isOngoing && it.packageName != packageName }
            // 只显示用户在应用管理中允许的应用
            ?.filter { allowed == null || allowed.contains(it.packageName) }
            ?.map { it.packageName }
            ?.distinct()
            ?.take(RingOverlayView.MAX_ICONS)
            ?.toList()
            ?: emptyList()

        prefs.edit()
            .putString("notification_packages", packages.joinToString("|"))
            .apply()
        HoleLightAccessibilityService.requestRefresh()
    }

    companion object {
        private const val KEY_ALLOWED_PACKAGES = "allowed_notification_packages"

        fun refreshFromSystem() {
            // 重新筛选当前通知，避免仅修改应用开关后仍保留旧图标
            current?.runCatchingPublish()
        }

        @Volatile private var current: HoleLightNotificationListener? = null
    }

    override fun onListenerConnected() {
        current = this
        super.onListenerConnected()
        publishActive()
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    private fun runCatchingPublish() {
        runCatching { publishActive() }
    }
}
