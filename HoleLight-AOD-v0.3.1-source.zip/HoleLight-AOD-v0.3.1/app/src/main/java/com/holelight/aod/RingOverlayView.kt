package com.holelight.aod

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.view.View
import kotlin.math.abs

class RingOverlayView(context: Context) : View(context) {
    private val prefs = context.getSharedPreferences("holelight", Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var icons: List<Drawable> = emptyList()

    fun refreshIcons() {
        val names = prefs.getString("notification_packages", "").orEmpty()
            .split("|").filter { it.isNotBlank() }.distinct().take(MAX_ICONS)
        icons = names.mapNotNull {
            runCatching { context.packageManager.getApplicationIcon(it) }.getOrNull()
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val diameter = prefs.getInt(KEY_DIAMETER, DEFAULT_DIAMETER).coerceIn(24, 180) * d
        val brightness = prefs.getInt(KEY_BRIGHTNESS, DEFAULT_BRIGHTNESS).coerceIn(20, 100) / 100f
        val xOffset = prefs.getInt(KEY_X_OFFSET, 0).coerceIn(-300, 300) * d
        val yOffset = prefs.getInt(KEY_Y_POSITION, DEFAULT_Y_POSITION).coerceIn(-200, 400) * d
        val radius = diameter * .5f

        // 自动读取显示屏刘海/挖孔区域。圆环中心对准最靠近屏幕水平中心的顶部 cutout。
        // 某些厂商可能不向无障碍覆盖层暴露 cutout；此时退回顶部 100dp 的手动微调基准。
        val autoCamera = prefs.getBoolean(KEY_AUTO_CAMERA, true)
        val cutoutRect = if (autoCamera && android.os.Build.VERSION.SDK_INT >= 28) {
            runCatching {
                rootWindowInsets?.displayCutout?.boundingRects
                    ?.filter { it.top <= height * 0.25f && it.width() > 0 && it.height() > 0 }
                    ?.minByOrNull { abs((it.left + it.right) / 2f - width / 2f) }
            }.getOrNull()
        } else null

        val baseCx: Float
        val baseCy: Float
        if (cutoutRect != null) {
            baseCx = (cutoutRect.left + cutoutRect.right) / 2f
            baseCy = (cutoutRect.top + cutoutRect.bottom) / 2f
        } else {
            baseCx = width / 2f
            baseCy = 100f * d
        }
        // 不再强制施加顶部安全距离，允许圆环围绕摄像头孔位显示。
        val cx = baseCx + xOffset
        val cy = baseCy + yOffset

        val colors = intArrayOf(
            0xFFFF3434.toInt(), 0xFFFFA52D.toInt(), 0xFFE9F33A.toInt(),
            0xFF32E58A.toInt(), 0xFF28C7F4.toInt(), 0xFF625CFF.toInt(),
            0xFFCB4BFF.toInt(), 0xFFFF348D.toInt(), 0xFFFF3434.toInt()
        )
        paint.alpha = (255 * brightness).toInt()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (3.2f * d).coerceAtMost(diameter * .09f)
        paint.shader = SweepGradient(cx, cy, colors, null)
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null
        paint.alpha = 255

        if (icons.isEmpty()) return
        val iconSize = (diameter * .38f).coerceIn(18f * d, 30f * d)
        val gap = 8f * d
        val total = icons.size * iconSize + (icons.size - 1) * gap
        var x = cx - total / 2f
        val top = cy + radius + 16f * d
        icons.forEach { icon ->
            icon.alpha = (255 * brightness).toInt()
            icon.setBounds(x.toInt(), top.toInt(), (x + iconSize).toInt(), (top + iconSize).toInt())
            icon.draw(canvas)
            x += iconSize + gap
        }
    }

    companion object {
        const val KEY_DIAMETER = "ring_diameter"
        const val KEY_BRIGHTNESS = "ring_brightness"
        const val KEY_X_OFFSET = "ring_x_offset"
        const val KEY_Y_POSITION = "ring_y_position"
        const val KEY_AUTO_CAMERA = "auto_camera_alignment"
        const val DEFAULT_DIAMETER = 54
        const val DEFAULT_BRIGHTNESS = 80
        const val DEFAULT_Y_POSITION = 0
        const val MAX_ICONS = 6
    }
}
