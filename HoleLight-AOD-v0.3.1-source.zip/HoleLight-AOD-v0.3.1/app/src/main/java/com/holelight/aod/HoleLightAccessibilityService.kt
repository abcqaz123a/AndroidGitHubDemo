package com.holelight.aod

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class HoleLightAccessibilityService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var overlay: RingOverlayView? = null
    private lateinit var keyguard: KeyguardManager
    private val main = Handler(Looper.getMainLooper())
    private val refreshTask = Runnable { refresh() }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        refresh()
    }

    // 合并短时间内密集的无障碍事件，避免反复重建/刷新覆盖层
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        main.removeCallbacks(refreshTask)
        main.postDelayed(refreshTask, 250L)
    }

    override fun onInterrupt() {}

    private fun attach() {
        if (overlay != null) return
        val view = RingOverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // 允许覆盖层布局延伸到屏幕挖孔/刘海区域；这不授予系统状态栏窗口类型。
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        runCatching {
            wm?.addView(view, params)
            overlay = view
        }
    }

    private fun refresh() {
        if (!::keyguard.isInitialized) return

        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        val previewEnabled = prefs.getBoolean("preview_enabled", false)
        val shouldShow = keyguard.isKeyguardLocked || previewEnabled

        if (!shouldShow) {
            overlay?.let { runCatching { wm?.removeView(it) } }
            overlay = null
            return
        }

        if (overlay == null) attach()
        overlay?.refreshIcons()
        overlay?.invalidate()
    }

    override fun onDestroy() {
        main.removeCallbacks(refreshTask)
        overlay?.let { runCatching { wm?.removeView(it) } }
        overlay = null
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var instance: HoleLightAccessibilityService? = null
        fun requestRefresh() {
            instance?.main?.post { instance?.refresh() }
        }
    }
}
