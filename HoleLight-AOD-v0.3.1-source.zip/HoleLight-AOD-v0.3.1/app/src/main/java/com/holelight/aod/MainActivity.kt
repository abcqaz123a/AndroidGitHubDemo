package com.holelight.aod

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("holelight", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var previewButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF101114.toInt())
        }
        scroll.addView(root)
        text("HoleLight", 30f)
        text("通知圆环 · 版本 0.3.1", 15f, 0xFFB8BBC4.toInt())
        text(
            "\n圆环支持自动识别前置摄像头并居中环绕；直径 24–180 dp，水平微调 ±300 dp，垂直微调 -200～+400 dp。最多显示 6 个允许显示的通知应用图标。\n" +
                "设置会保存在本机。打开本应用时自动显示圆环预览，方便调整；离开应用后自动关闭预览并恢复锁屏显示逻辑。",
            14f, 0xFFE0E2E8.toInt()
        )

        previewButton = Button(this).apply {
            setOnClickListener {
                val enabled = !prefs.getBoolean(KEY_PREVIEW_ENABLED, true)
                prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, enabled).apply()
                updatePreviewButton()
                HoleLightAccessibilityService.requestRefresh()
            }
        }
        root.addView(previewButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 8; bottomMargin = 12 })
        updatePreviewButton()

        val autoCamera = CheckBox(this).apply {
            text = "自动对准前置摄像头（推荐）"
            setTextColor(0xFFE0E2E8.toInt())
            textSize = 15f
            isChecked = prefs.getBoolean(RingOverlayView.KEY_AUTO_CAMERA, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(RingOverlayView.KEY_AUTO_CAMERA, checked).apply()
                HoleLightAccessibilityService.requestRefresh()
            }
        }
        root.addView(autoCamera)

        addSeek("圆环直径", RingOverlayView.KEY_DIAMETER, 24, 180,
            RingOverlayView.DEFAULT_DIAMETER, " dp")
        addSeek("圆环亮度", RingOverlayView.KEY_BRIGHTNESS, 20, 100,
            RingOverlayView.DEFAULT_BRIGHTNESS, "%")
        addSeek("摄像头水平微调（自动模式下相对摄像头）", RingOverlayView.KEY_X_OFFSET, -300, 300, 0, " dp")
        addSeek("摄像头垂直微调（自动模式下相对摄像头）", RingOverlayView.KEY_Y_POSITION, -200, 400,
            RingOverlayView.DEFAULT_Y_POSITION, " dp")

        button("恢复默认参数") {
            prefs.edit()
                .putInt(RingOverlayView.KEY_DIAMETER, RingOverlayView.DEFAULT_DIAMETER)
                .putInt(RingOverlayView.KEY_BRIGHTNESS, RingOverlayView.DEFAULT_BRIGHTNESS)
                .putInt(RingOverlayView.KEY_X_OFFSET, 0)
                .putInt(RingOverlayView.KEY_Y_POSITION, RingOverlayView.DEFAULT_Y_POSITION)
                .putBoolean(RingOverlayView.KEY_AUTO_CAMERA, true)
                .apply()
            recreate()
            HoleLightAccessibilityService.requestRefresh()
        }
        button("① 开启无障碍显示服务") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("② 开启通知读取权限") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("③ 打开系统显示设置") {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        buildAppFilterSection()
        text(
            "\n使用说明\n1. 启用无障碍显示服务和通知读取权限。\n" +
                "2. 返回桌面并锁屏，观察圆环和通知图标。\n" +
                "3. 默认自动识别前置摄像头并居中；如有偏差，使用水平/垂直微调。\n\n" +
                "重要限制：第三方无障碍覆盖层不属于系统原生 AOD 内容。HyperOS 可能在真正低功耗 AOD 状态隐藏它；本应用不会点亮屏幕或伪装常亮 AOD。",
            13f, 0xFF9DA3AE.toInt()
        )
        setContentView(scroll)
    }

    private fun buildAppFilterSection() {
        text("\\n通知应用管理", 20f, 0xFFFFFFFF.toInt())

        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        val allowedKey = "allowed_notification_packages"
        if (!prefs.contains(allowedKey)) {
            prefs.edit().putStringSet(allowedKey, apps.map { it.packageName }.toSet()).apply()
        }

        val countLabel = TextView(this).apply {
            setTextColor(0xFFB8BBC4.toInt())
            textSize = 13f
        }
        val appContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        fun selectedPackages(): MutableSet<String> =
            (prefs.getStringSet(allowedKey, emptySet()) ?: emptySet()).toMutableSet()

        fun refreshCount() {
            countLabel.text = "已开启 ${selectedPackages().size} / ${apps.size} 个应用"
        }

        fun rebuildRows() {
            appContainer.removeAllViews()
            val selected = selectedPackages()
            apps.forEach { app ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding(4, 5, 4, 5)
                }
                val icon = ImageView(this).apply {
                    setImageDrawable(pm.getApplicationIcon(app))
                    layoutParams = LinearLayout.LayoutParams(
                        (32 * resources.displayMetrics.density).toInt(),
                        (32 * resources.displayMetrics.density).toInt()
                    )
                }
                val check = CheckBox(this).apply {
                    text = pm.getApplicationLabel(app).toString()
                    setTextColor(0xFFE0E2E8.toInt())
                    isChecked = selected.contains(app.packageName)
                    setOnCheckedChangeListener { _, checked ->
                        val now = selectedPackages()
                        if (checked) now.add(app.packageName) else now.remove(app.packageName)
                        prefs.edit().putStringSet(allowedKey, now).apply()
                        refreshCount()
                        HoleLightNotificationListener.refreshFromSystem()
                    }
                }
                row.addView(icon)
                row.addView(check, LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                ))
                appContainer.addView(row)
            }
            refreshCount()
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val selectAll = Button(this).apply {
            text = "一键全选"
            setOnClickListener {
                prefs.edit().putStringSet(allowedKey, apps.map { it.packageName }.toSet()).apply()
                rebuildRows()
                HoleLightNotificationListener.refreshFromSystem()
            }
        }
        val disableAll = Button(this).apply {
            text = "一键全关闭"
            setOnClickListener {
                prefs.edit().putStringSet(allowedKey, emptySet()).apply()
                rebuildRows()
                HoleLightNotificationListener.refreshFromSystem()
            }
        }
        actions.addView(selectAll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(disableAll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(countLabel)
        root.addView(actions)
        root.addView(appContainer)
        rebuildRows()
    }

    override fun onResume() {
        super.onResume()
        // 每次进入设置界面自动开启预览，便于直接调整参数
        prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, true).apply()
        if (::previewButton.isInitialized) updatePreviewButton()
        HoleLightAccessibilityService.requestRefresh()
    }

    override fun onStop() {
        // 离开应用后关闭临时预览，不影响锁屏状态下的正常显示
        prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, false).apply()
        HoleLightAccessibilityService.requestRefresh()
        super.onStop()
    }

    private fun updatePreviewButton() {
        val enabled = prefs.getBoolean(KEY_PREVIEW_ENABLED, true)
        previewButton.text = if (enabled) "圆环预览：已开启（点击隐藏）" else "圆环预览：已关闭（点击显示）"
    }

    private fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) {
        root.addView(TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 10 })
    }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 7 })
    }

    companion object {
        private const val KEY_PREVIEW_ENABLED = "preview_enabled"
    }

    private fun addSeek(
        title: String, key: String, min: Int, max: Int, default: Int, suffix: String
    ) {
        val label = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
        }
        val seek = SeekBar(this).apply { this.max = max - min }
        fun updateLabel(value: Int) { label.text = "$title：$value$suffix" }
        val initial = prefs.getInt(key, default).coerceIn(min, max)
        seek.progress = initial - min
        updateLabel(initial)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress + min
                updateLabel(value)
                prefs.edit().putInt(key, value).apply()
                if (fromUser) HoleLightAccessibilityService.requestRefresh()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        root.addView(label)
        root.addView(seek, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 12 })
    }
}
