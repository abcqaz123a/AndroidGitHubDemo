package com.holelight.aod

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin

class RingOverlayView(context: Context) : View(context) {
    private val prefs = context.getSharedPreferences("holelight", Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gradientMatrix = Matrix()
    private var icons: List<Drawable> = emptyList()
    private var lastPackageSnapshot: String? = null
    private var animationPhase = 0f
    private var animator: ValueAnimator? = null
    private var runningStyle = -1
    private var runningSpeed = -1

    fun refreshIcons() {
        ensureAnimation()
        val snapshot = prefs.getString("notification_packages", "").orEmpty()
        if (snapshot == lastPackageSnapshot) return
        lastPackageSnapshot = snapshot
        val names = snapshot.split("|").filter { it.isNotBlank() }.distinct().take(MAX_ICONS)
        icons = names.mapNotNull { runCatching { context.packageManager.getApplicationIcon(it) }.getOrNull() }
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startAnimationIfNeeded()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    private fun startAnimationIfNeeded() = ensureAnimation()

    private fun ensureAnimation() {
        val style = prefs.getInt(KEY_STYLE, STYLE_STATIC)
        val speed = prefs.getInt(KEY_SPEED, DEFAULT_SPEED).coerceIn(1, 10)
        if (style == runningStyle && speed == runningSpeed && (style == STYLE_STATIC || animator?.isRunning == true)) return
        animator?.cancel(); animator = null
        runningStyle = style; runningSpeed = speed
        if (style == STYLE_STATIC || !isAttachedToWindow) { invalidate(); return }
        val duration = (12000L - (speed - 1) * 1080L).coerceAtLeast(1200L)
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { animationPhase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val diameter = prefs.getInt(KEY_DIAMETER, DEFAULT_DIAMETER).coerceIn(24, 180) * d
        val brightness = prefs.getInt(KEY_BRIGHTNESS, DEFAULT_BRIGHTNESS).coerceIn(20, 100) / 100f
        val xOffset = prefs.getInt(KEY_X_OFFSET, 0).coerceIn(-300, 300) * d
        val yOffset = prefs.getInt(KEY_Y_POSITION, DEFAULT_Y_POSITION).coerceIn(-200, 400) * d
        val radius = diameter * .5f
        val autoCamera = prefs.getBoolean(KEY_AUTO_CAMERA, true)
        val cutoutRect = if (autoCamera && android.os.Build.VERSION.SDK_INT >= 28) runCatching {
            rootWindowInsets?.displayCutout?.boundingRects?.filter { it.top <= height * .25f && it.width() > 0 && it.height() > 0 }
                ?.minByOrNull { abs((it.left + it.right) / 2f - width / 2f) }
        }.getOrNull() else null
        val baseCx = cutoutRect?.let { (it.left + it.right) / 2f } ?: width / 2f
        val baseCy = cutoutRect?.let { (it.top + it.bottom) / 2f } ?: 100f * d
        val cx = baseCx + xOffset
        val cy = baseCy + yOffset
        val colors = intArrayOf(0xFFFF3434.toInt(), 0xFFFFA52D.toInt(), 0xFFE9F33A.toInt(), 0xFF32E58A.toInt(), 0xFF28C7F4.toInt(), 0xFF625CFF.toInt(), 0xFFCB4BFF.toInt(), 0xFFFF348D.toInt(), 0xFFFF3434.toInt())
        val style = prefs.getInt(KEY_STYLE, STYLE_STATIC)
        val wave = ((sin(Math.toRadians(animationPhase.toDouble())) + 1.0) / 2.0).toFloat()
        val alphaFactor = when (style) { STYLE_BREATHING -> .38f + .62f * wave; STYLE_PULSE -> .58f + .42f * wave; else -> 1f }
        paint.alpha = (255 * brightness * alphaFactor).toInt().coerceIn(0, 255)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (if (style == STYLE_PULSE) (2.5f + 1.8f * wave) else 3.2f) * d
        paint.strokeWidth = paint.strokeWidth.coerceAtMost(diameter * .09f)
        val gradient = SweepGradient(cx, cy, colors, null)
        if (style == STYLE_FLOW) {
            gradientMatrix.setRotate(animationPhase, cx, cy)
            gradient.setLocalMatrix(gradientMatrix)
        }
        paint.shader = gradient
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null
        paint.alpha = 255

        if (icons.isEmpty()) return
        val iconScale = prefs.getInt(KEY_ICON_SIZE, DEFAULT_ICON_SIZE).coerceIn(60, 140) / 100f
        val gapDp = prefs.getInt(KEY_ICON_GAP, DEFAULT_ICON_GAP).coerceIn(2, 20)
        val requestedSize = (diameter * .38f).coerceIn(18f * d, 30f * d) * iconScale
        val gap = gapDp * d
        val availableWidth = (width - 32f * d).coerceAtLeast(1f)
        val fittedSize = ((availableWidth - (icons.size - 1) * gap) / icons.size).coerceAtLeast(12f * d)
        val iconSize = minOf(requestedSize, fittedSize)
        val actualGap = if (icons.size > 1) minOf(gap, ((availableWidth - icons.size * iconSize) / (icons.size - 1)).coerceAtLeast(1f * d)) else 0f
        val total = icons.size * iconSize + (icons.size - 1) * actualGap
        var x = (width - total) / 2f
        val top = cy + radius + 16f * d
        icons.forEach { icon ->
            icon.alpha = (255 * brightness).toInt()
            icon.setBounds(x.toInt(), top.toInt(), (x + iconSize).toInt(), (top + iconSize).toInt())
            icon.draw(canvas); x += iconSize + actualGap
        }
    }

    companion object {
        const val KEY_DIAMETER = "ring_diameter"
        const val KEY_BRIGHTNESS = "ring_brightness"
        const val KEY_X_OFFSET = "ring_x_offset"
        const val KEY_Y_POSITION = "ring_y_position"
        const val KEY_AUTO_CAMERA = "auto_camera_alignment"
        const val KEY_ICON_SIZE = "notification_icon_size"
        const val KEY_ICON_GAP = "notification_icon_gap"
        const val KEY_STYLE = "ring_style"
        const val KEY_SPEED = "ring_animation_speed"
        const val STYLE_STATIC = 0
        const val STYLE_FLOW = 1
        const val STYLE_BREATHING = 2
        const val STYLE_PULSE = 3
        const val DEFAULT_SPEED = 5
        const val DEFAULT_ICON_SIZE = 100
        const val DEFAULT_ICON_GAP = 8
        const val DEFAULT_DIAMETER = 30
        const val DEFAULT_BRIGHTNESS = 80
        const val DEFAULT_Y_POSITION = 3
        const val MAX_ICONS = 8
    }
}
