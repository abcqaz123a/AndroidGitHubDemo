package com.holelight.aod

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.view.accessibility.AccessibilityEvent

class HoleLightAccessibilityService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var overlay: RingOverlayView? = null
    private var keyguard: KeyguardManager? = null
    private var power: PowerManager? = null
    private val main = Handler(Looper.getMainLooper())
    private val refreshTask = Runnable { refresh() }
    private val retryTask = Runnable { refresh() }
    private val watchdogTask = Runnable { runWatchdog() }
    private val pendingRefreshes = mutableSetOf<Runnable>()
    private var refreshGeneration = 0
    private var receiverRegistered = false
    private var attachRetryCount = 0
    private var lastNotificationSyncAt = 0L
    private var lastWindowEventAt = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // 圆环窗口应在屏幕关闭前已经预创建；这里仅同步现有窗口的可见状态，绝不依赖熄屏后 addView。
                    syncExistingOverlayVisibility()
                    scheduleWatchdog(15_000L)
                }
                Intent.ACTION_SCREEN_ON -> {
                    attachRetryCount = 0
                    scheduleRefreshBurst()
                    scheduleWatchdog(1_200L)
                }
                Intent.ACTION_USER_PRESENT -> {
                    // 解锁后隐藏但保留窗口，下一次锁屏可直接切换为可见。
                    scheduleRefresh(100L)
                    scheduleWatchdog(2_000L)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        power = getSystemService(Context.POWER_SERVICE) as PowerManager
        registerScreenReceiver()
        attachRetryCount = 0
        scheduleRefreshBurst()
        scheduleWatchdog(1_500L)
    }

    private fun registerScreenReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(screenReceiver, filter)
            }
            receiverRegistered = true
        }
    }

    /**
     * 窗口状态变化同时覆盖锁屏和解锁转换：锁屏时显示预创建窗口，解锁时隐藏窗口。
     * 不读取窗口内容，也不依赖某个 ROM 特有的 Keyguard 包名。
     */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastWindowEventAt < 500L) return
        lastWindowEventAt = now
        scheduleRefresh(100L)
    }

    override fun onInterrupt() = Unit

    private fun clearScheduledRefreshes() {
        refreshGeneration++
        main.removeCallbacks(refreshTask)
        main.removeCallbacks(retryTask)
        pendingRefreshes.forEach { main.removeCallbacks(it) }
        pendingRefreshes.clear()
    }

    private fun scheduleRefresh(delay: Long = 0L) {
        clearScheduledRefreshes()
        main.postDelayed(refreshTask, delay.coerceAtLeast(0L))
        scheduleWatchdog(2_500L)
    }

    private fun scheduleWatchdog(delay: Long) {
        main.removeCallbacks(watchdogTask)
        main.postDelayed(watchdogTask, delay.coerceAtLeast(500L))
    }

    private fun runWatchdog() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        if (!prefs.getBoolean("app_enabled", true)) {
            attachRetryCount = 0
            main.removeCallbacks(retryTask)
            removeOverlay()
            return
        }

        val pm = power ?: (getSystemService(Context.POWER_SERVICE) as PowerManager).also { power = it }
        if (!pm.isInteractive) {
            // 不持有 WakeLock；屏幕关闭时只保留系统已有窗口。
            syncExistingOverlayVisibility()
            scheduleWatchdog(15_000L)
            return
        }

        val km = keyguard ?: (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).also { keyguard = it }
        if (km.isKeyguardLocked) {
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastNotificationSyncAt >= 30_000L) {
                lastNotificationSyncAt = now
                HoleLightNotificationListener.refreshFromSystem()
            }
        }

        refresh()
        scheduleWatchdog(if (km.isKeyguardLocked) 4_000L else 12_000L)
    }

    private fun scheduleRefreshBurst() {
        clearScheduledRefreshes()
        val generation = refreshGeneration
        val delays = longArrayOf(0L, 180L, 450L, 900L, 1600L, 2800L)
        delays.forEach { delay ->
            lateinit var task: Runnable
            task = Runnable {
                pendingRefreshes.remove(task)
                if (generation == refreshGeneration) refresh()
            }
            pendingRefreshes.add(task)
            main.postDelayed(task, delay)
        }
    }

    private fun notificationPackages(prefs: android.content.SharedPreferences): List<String> =
        prefs.getString("notification_packages", "").orEmpty()
            .split("|").filter { it.isNotBlank() }.distinct()

    private fun attach(): Boolean {
        if (overlay?.isAttachedToWindow == true) return true
        val manager = wm ?: (getSystemService(Context.WINDOW_SERVICE) as WindowManager).also { wm = it }
        val view = RingOverlayView(this)
        @Suppress("DEPRECATION")
        val showWhenLockedFlag = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                showWhenLockedFlag,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        return try {
            manager.addView(view, params)
            overlay = view
            view.refreshIcons()
            true
        } catch (_: Exception) {
            overlay = null
            false
        }
    }

    private fun removeOverlay() {
        val old = overlay ?: return
        overlay = null
        runCatching {
            if (old.isAttachedToWindow) wm?.removeViewImmediate(old)
        }
    }

    private fun scheduleAttachRetry() {
        if (attachRetryCount >= 8) return
        val delays = longArrayOf(300L, 500L, 800L, 1200L, 1800L, 2500L, 3500L, 5000L)
        val delay = delays[attachRetryCount.coerceIn(0, delays.lastIndex)]
        attachRetryCount++
        main.removeCallbacks(retryTask)
        main.postDelayed(retryTask, delay)
    }

    /**
     * 关键策略：只要仍有未清除通知，就在屏幕亮着时预先 attach。
     * 解锁状态设为 INVISIBLE 而不是 removeView；锁屏时只切换 VISIBLE。
     * 因此第一次熄屏不再需要在 isInteractive=false 后新建窗口。
     */
    private fun refresh() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        if (!prefs.getBoolean("app_enabled", true)) {
            attachRetryCount = 0
            main.removeCallbacks(retryTask)
            removeOverlay()
            return
        }

        val km = keyguard ?: (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).also { keyguard = it }
        val pm = power ?: (getSystemService(Context.POWER_SERVICE) as PowerManager).also { power = it }
        if (!pm.isInteractive) {
            // 熄屏后不创建新窗口，只同步已经预创建窗口的可见性。
            syncExistingOverlayVisibility()
            return
        }

        val isLocked = km.isKeyguardLocked
        val previewEnabled = prefs.getBoolean("preview_enabled", false)
        val activePackages = notificationPackages(prefs)
        val shouldKeepWindow = previewEnabled || activePackages.isNotEmpty()
        if (!shouldKeepWindow) {
            attachRetryCount = 0
            main.removeCallbacks(retryTask)
            removeOverlay()
            return
        }

        // 不用 isShown 判断健康状态：INVISIBLE 的预创建窗口本来就不是 shown。
        val current = overlay
        if (current?.isAttachedToWindow != true) {
            if (current != null && current.isAttachedToWindow) {
                runCatching { wm?.removeViewImmediate(current) }
            }
            overlay = null
            if (!attach()) {
                scheduleAttachRetry()
                return
            }
        }

        attachRetryCount = 0
        main.removeCallbacks(retryTask)
        overlay?.apply {
            refreshIcons()
            visibility = if (previewEnabled || isLocked) View.VISIBLE else View.INVISIBLE
            alpha = 1f
            if (visibility == View.VISIBLE) bringToFront()
            invalidate()
        }
    }

    private fun syncExistingOverlayVisibility() {
        val view = overlay ?: return
        if (!view.isAttachedToWindow) return
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        if (!prefs.getBoolean("app_enabled", true)) {
            removeOverlay()
            return
        }
        val km = keyguard ?: (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).also { keyguard = it }
        val previewEnabled = prefs.getBoolean("preview_enabled", false)
        val hasNotifications = notificationPackages(prefs).isNotEmpty()
        view.visibility = if (previewEnabled || (km.isKeyguardLocked && hasNotifications)) View.VISIBLE else View.INVISIBLE
        if (view.visibility == View.VISIBLE) {
            view.refreshIcons()
            view.invalidate()
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        clearScheduledRefreshes()
        main.removeCallbacks(watchdogTask)
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(screenReceiver) }
        receiverRegistered = false
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        clearScheduledRefreshes()
        main.removeCallbacks(watchdogTask)
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(screenReceiver) }
        receiverRegistered = false
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var instance: HoleLightAccessibilityService? = null
        fun requestRefresh(delay: Long = 80L) {
            instance?.scheduleRefresh(delay)
        }
    }
}
