package com.holelight.aod

import android.content.ComponentName
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * 只维护系统当前仍存在的通知快照。
 * 收到新通知时立即更新缓存并通知覆盖层；服务重连时从系统完整重建，
 * 避免进程被回收后仅靠内存缓存导致锁屏通知丢失。
 */
class HoleLightNotificationListener : NotificationListenerService() {

    private data class Notice(
        val key: String,
        val packageName: String,
        val postTime: Long,
        val ongoing: Boolean
    )

    private val notices = LinkedHashMap<String, Notice>()

    override fun onListenerConnected() {
        super.onListenerConnected()
        current = this
        syncFromSystem()
    }

    override fun onListenerDisconnected() {
        if (current === this) current = null
        super.onListenerDisconnected()
        // 仅在系统明确断开回调时请求重新绑定；这是 Android 文档允许的调用时机。
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            runCatching {
                NotificationListenerService.requestRebind(ComponentName(this, HoleLightNotificationListener::class.java))
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        notices[sbn.key] = Notice(
            key = sbn.key,
            packageName = sbn.packageName,
            postTime = sbn.postTime,
            ongoing = sbn.isOngoing
        )
        // 新通知不等待下一次屏幕状态广播，直接刷新允许应用集合。
        publishActive()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        notices.remove(sbn.key)
        // 通知分组、摘要及系统批量清理可能造成单条回调与实际状态短暂不一致，
        // 以系统活动通知快照为准。
        syncFromSystem()
    }

    private fun syncFromSystem() {
        runCatching {
            val active = getActiveNotifications() ?: emptyArray()
            notices.clear()
            active.forEach { sbn ->
                notices[sbn.key] = Notice(
                    key = sbn.key,
                    packageName = sbn.packageName,
                    postTime = sbn.postTime,
                    ongoing = sbn.isOngoing
                )
            }
        }
        publishActive()
    }

    private fun publishActive() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        val allowed = prefs.getStringSet(KEY_ALLOWED_PACKAGES, emptySet())?.toSet().orEmpty()

        // B 规则：所有尚未从系统通知栏清除的通知对应应用；同一应用只显示一个图标。
        val packages = notices.values
            .asSequence()
            .filter { !it.ongoing && it.packageName != packageName }
            .filter { allowed.contains(it.packageName) }
            .sortedByDescending { it.postTime }
            .map { it.packageName }
            .distinct()
            .take(RingOverlayView.MAX_ICONS)
            .toList()

        // apply 会立即更新本进程 SharedPreferences 内存值，覆盖层延迟刷新时可读取到新值。
        prefs.edit()
            .putString(KEY_NOTIFICATION_PACKAGES, packages.joinToString("|"))
            .putInt(KEY_ACTIVE_NOTIFICATION_COUNT, notices.size)
            .putLong(KEY_LAST_NOTIFICATION_UPDATE, System.currentTimeMillis())
            .apply()

        HoleLightAccessibilityService.requestRefresh(60L)
    }

    companion object {
        private const val KEY_ALLOWED_PACKAGES = "allowed_notification_packages"
        private const val KEY_NOTIFICATION_PACKAGES = "notification_packages"
        private const val KEY_ACTIVE_NOTIFICATION_COUNT = "active_notification_count"
        private const val KEY_LAST_NOTIFICATION_UPDATE = "last_notification_update"

        @Volatile private var current: HoleLightNotificationListener? = null

        fun refreshFromSystem() {
            current?.let { service -> runCatching { service.syncFromSystem() } }
        }
    }

    override fun onDestroy() {
        if (current === this) current = null
        notices.clear()
        super.onDestroy()
    }
}
