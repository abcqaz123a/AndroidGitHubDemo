# Android GitHub Actions Demo

A minimal native Android app (Java) for testing the GitHub-to-APK workflow.

## App
- App name: GitHub APK Demo
- Package: `com.example.androiddemo`
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- No third-party libraries

## Build
From this directory, run `gradle assembleDebug` with JDK 17 and Android SDK platform 35 installed.

APK output: `app/build/outputs/apk/debug/app-debug.apk`

The accompanying GitHub Actions workflow builds this project in GitHub's cloud runner.
