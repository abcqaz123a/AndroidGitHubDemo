package com.holelight.aod

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("holelight", MODE_PRIVATE) }
    private lateinit var page: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var previewButton: TextView
    private var currentPage = "home"

    private val bg = Color.rgb(10, 13, 17)
    private val panel = Color.rgb(21, 27, 33)
    private val panel2 = Color.rgb(27, 35, 42)
    private val accent = Color.rgb(0, 205, 174)
    private val mainText = Color.rgb(239, 245, 247)
    private val muted = Color.rgb(145, 160, 169)
    private val line = Color.rgb(42, 54, 62)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 10, 13)
        window.navigationBarColor = Color.rgb(7, 10, 13)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        window.decorView.systemUiVisibility = 0

        val host = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(bg)
        }
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
            setBackgroundColor(bg)
        }
        scroll.addView(page, ViewGroup.LayoutParams(-1, -2))
        host.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(host)

        // Android 15 / HyperOS edge-to-edge: apply real system-bar insets so title never sits under status icons.
        if (Build.VERSION.SDK_INT >= 30) {
            host.setOnApplyWindowInsetsListener { v, insets ->
                val bars = insets.getInsets(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                v.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
            host.requestApplyInsets()
        } else {
            host.setPadding(0, dp(24), 0, dp(24))
        }
        showHome()
    }

    private fun showHome() {
        currentPage = "home"
        page.removeAllViews()
        header("HoleLight", "RGB 通知圆环", false)

        val hero = card()
        hero.orientation = LinearLayout.VERTICAL
        hero.setPadding(dp(18), dp(16), dp(18), dp(16))
        rowIn(hero) {
            val icon = TextView(this@MainActivity).apply {
                text = "◉"
                textSize = 34f
                setTextColor(accent)
                gravity = Gravity.CENTER
            }
            addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
            column {
                label("通知圆环", 18f, mainText, true)
                label("摄像头周围的 RGB 状态灯", 12f, muted)
            }
        }
        previewButton = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            background = rounded(panel2, 12)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setOnClickListener {
                val enabled = !prefs.getBoolean(KEY_PREVIEW_ENABLED, true)
                prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, enabled).apply()
                updatePreviewButton()
                HoleLightAccessibilityService.requestRefresh()
            }
        }
        hero.addView(previewButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        updatePreviewButton()
        page.addView(hero, match().bottom(16))

        sectionTitle("外观设置", "调整圆环的位置和视觉效果")
        val appearance = card()
        appearance.setPadding(dp(16), dp(14), dp(16), dp(8))
        val auto = CheckBox(this).apply {
            text = "自动对准前置摄像头"
            textSize = 14f
            setTextColor(mainText)
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
            isChecked = prefs.getBoolean(RingOverlayView.KEY_AUTO_CAMERA, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(RingOverlayView.KEY_AUTO_CAMERA, checked).apply()
                HoleLightAccessibilityService.requestRefresh()
            }
        }
        appearance.addView(auto)
        addSeek(appearance, "圆环直径", RingOverlayView.KEY_DIAMETER, 24, 180, RingOverlayView.DEFAULT_DIAMETER, " dp")
        addSeek(appearance, "圆环亮度", RingOverlayView.KEY_BRIGHTNESS, 20, 100, RingOverlayView.DEFAULT_BRIGHTNESS, "%")
        addSeek(appearance, "水平位置", RingOverlayView.KEY_X_OFFSET, -300, 300, 0, " dp")
        addSeek(appearance, "垂直位置", RingOverlayView.KEY_Y_POSITION, -200, 400, RingOverlayView.DEFAULT_Y_POSITION, " dp")
        page.addView(appearance, match().bottom(14))

        sectionTitle("通知图标", "设置图标显示大小与排列")
        val icons = card()
        icons.setPadding(dp(16), dp(12), dp(16), dp(8))
        addSeek(icons, "图标大小", RingOverlayView.KEY_ICON_SIZE, 60, 140, RingOverlayView.DEFAULT_ICON_SIZE, "%")
        addSeek(icons, "图标间距", RingOverlayView.KEY_ICON_GAP, 2, 20, RingOverlayView.DEFAULT_ICON_GAP, " dp")
        page.addView(icons, match().bottom(16))

        actionButton("保存设置", true) { saveSettings() }
        actionButton("恢复默认设置", false) { resetSettings() }
        menuEntry("设置与应用管理", "应用筛选 · 权限 · 系统设置", "☰") { showMenu() }
        label("HoleLight  ·  0.4.3", 11f, muted).apply { gravity = Gravity.CENTER }
            .also { page.addView(it, match().top(18)) }
    }

    private fun showMenu() {
        currentPage = "menu"
        page.removeAllViews()
        header("菜单", "管理应用与系统权限", true)
        menuEntry("通知应用列表", "选择哪些应用可以显示通知图标", "▦") { showApps() }
        menuEntry("无障碍显示服务", "开启圆环覆盖层所需的显示服务", "◉") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        menuEntry("通知读取权限", "允许读取未清除通知的应用信息", "♧") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        menuEntry("系统显示设置", "打开手机显示与息屏相关设置", "☼") {
            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        }
        menuEntry("关于 HoleLight", "版本信息、使用说明与兼容性提示", "ⓘ") { showAbout() }
        label("权限只在本机使用，不读取通知正文。", 12f, muted).apply {
            setPadding(dp(4), dp(20), dp(4), 0)
            page.addView(this)
        }
    }

    private fun showApps() {
        currentPage = "apps"
        page.removeAllViews()
        header("通知应用", "选择允许显示通知图标的应用", true)
        val pm = packageManager
        val apps = runCatching {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }.getOrDefault(emptyList()).filter { it.packageName != packageName }
            .sortedBy { runCatching { pm.getApplicationLabel(it).toString().lowercase() }.getOrDefault(it.packageName) }

        val allowedKey = "allowed_notification_packages"
        val knownKey = "known_app_packages"
        val installed = apps.map { it.packageName }.toSet()
        val known = (prefs.getStringSet(knownKey, emptySet()) ?: emptySet()).toMutableSet()
        val allowed = (prefs.getStringSet(allowedKey, emptySet()) ?: emptySet()).toMutableSet()
        if (!prefs.contains(allowedKey)) allowed.addAll(installed)
        else if (prefs.contains(knownKey)) allowed.addAll(installed - known)
        allowed.retainAll(installed)
        prefs.edit().putStringSet(allowedKey, allowed).putStringSet(knownKey, installed).apply()

        val summary = label("", 13f, accent, true)
        val search = EditText(this).apply {
            hint = "搜索应用名称"
            setSingleLine(true)
            textSize = 14f
            setTextColor(mainText)
            setHintTextColor(muted)
            background = rounded(panel, 10)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val onlyOn = CheckBox(this).apply {
            text = "只显示已开启"
            textSize = 13f
            setTextColor(mainText)
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        lateinit var rebuild: () -> Unit
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val listScroll = ScrollView(this).apply { isFillViewport = false }
        listScroll.addView(list)
        page.addView(summary, match().bottom(10))
        page.addView(search, match().bottom(8))
        page.addView(onlyOn, match().bottom(8))
        actions.addView(smallAction("全选") {
            prefs.edit().putStringSet(allowedKey, installed).apply(); rebuild()
            HoleLightNotificationListener.refreshFromSystem()
        }, LinearLayout.LayoutParams(0, dp(42), 1f))
        actions.addView(smallAction("全关闭") {
            prefs.edit().putStringSet(allowedKey, emptySet()).apply(); rebuild()
            HoleLightNotificationListener.refreshFromSystem()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8) })
        page.addView(actions, match().bottom(12))
        page.addView(listScroll, LinearLayout.LayoutParams(-1, -2))

        fun selected() = (prefs.getStringSet(allowedKey, emptySet()) ?: emptySet()).toMutableSet()
        rebuild = {
            list.removeAllViews()
            val chosen = selected()
            summary.text = "已启用 ${chosen.size} / ${apps.size} 个应用"
            val query = search.text.toString().trim().lowercase()
            val visible = apps.filter { app ->
                val name = runCatching { pm.getApplicationLabel(app).toString() }.getOrDefault(app.packageName)
                (query.isEmpty() || name.lowercase().contains(query) || app.packageName.lowercase().contains(query)) &&
                    (!onlyOn.isChecked || chosen.contains(app.packageName))
            }
            visible.forEach { app ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(7), dp(10), dp(7))
                    background = rounded(panel, 10)
                }
                val icon = ImageView(this).apply {
                    setImageDrawable(runCatching { pm.getApplicationIcon(app) }.getOrNull())
                }
                row.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
                val check = CheckBox(this).apply {
                    text = runCatching { pm.getApplicationLabel(app).toString() }.getOrDefault(app.packageName)
                    textSize = 14f
                    setTextColor(mainText)
                    buttonTintList = android.content.res.ColorStateList.valueOf(accent)
                    isChecked = chosen.contains(app.packageName)
                    setOnCheckedChangeListener { _, checked ->
                        val now = selected()
                        if (checked) now.add(app.packageName) else now.remove(app.packageName)
                        prefs.edit().putStringSet(allowedKey, now).apply()
                        summary.text = "已启用 ${now.size} / ${apps.size} 个应用"
                        if (onlyOn.isChecked && !checked) rebuild()
                        HoleLightNotificationListener.refreshFromSystem()
                    }
                }
                row.addView(check, LinearLayout.LayoutParams(0, -2, 1f))
                list.addView(row, match().bottom(6))
            }
            if (visible.isEmpty()) list.addView(label("没有匹配的应用", 13f, muted).apply { setPadding(dp(12), dp(18), dp(12), dp(18)) })
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { rebuild() }
            override fun afterTextChanged(s: Editable?) {}
        })
        onlyOn.setOnCheckedChangeListener { _, _ -> rebuild() }
        rebuild()
    }

    private fun showAbout() {
        currentPage = "about"
        page.removeAllViews()
        header("关于", "HoleLight RGB 通知圆环", true)
        val box = card()
        box.setPadding(dp(16), dp(16), dp(16), dp(16))
        box.addView(label("版本 0.4.3", 18f, mainText, true))
        box.addView(label("圆环围绕前置摄像头显示；通知图标仅显示已允许应用中仍未清除的通知。", 14f, muted).apply { setPadding(0, dp(10), 0, 0) })
        box.addView(label("隐私说明", 15f, accent, true).apply { setPadding(0, dp(18), 0, dp(5)) })
        box.addView(label("应用不读取通知正文，不上传通知数据。应用筛选与通知状态保存在本机。", 13f, muted))
        box.addView(label("兼容性说明", 15f, accent, true).apply { setPadding(0, dp(18), 0, dp(5)) })
        box.addView(label("当前采用无障碍覆盖层方案，并非小米系统签名的原生 AOD。HyperOS 可能在真正低功耗息屏状态隐藏第三方覆盖层。", 13f, muted))
        page.addView(box, match())
    }

    private fun header(title: String, subtitle: String, back: Boolean) {
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        if (back) {
            val b = TextView(this).apply {
                text = "‹"
                textSize = 34f
                setTextColor(accent)
                gravity = Gravity.CENTER
                setOnClickListener { if (currentPage == "apps" || currentPage == "about") showMenu() else showHome() }
            }
            top.addView(b, LinearLayout.LayoutParams(dp(42), dp(48)))
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 26f, mainText, true))
        texts.addView(label(subtitle, 12f, muted).apply { setPadding(0, dp(3), 0, 0) })
        top.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(top, match().bottom(20))
    }

    private fun sectionTitle(title: String, sub: String) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wrap.addView(label(title, 17f, mainText, true))
        wrap.addView(label(sub, 12f, muted).apply { setPadding(0, dp(3), 0, 0) })
        page.addView(wrap, match().bottom(10))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(panel, 16)
    }

    private fun rowIn(parent: LinearLayout, content: LinearLayout.() -> Unit) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; content() }
        parent.addView(r, match())
    }

    private fun LinearLayout.column(content: LinearLayout.() -> Unit) {
        val c = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; content() }
        addView(c, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun menuEntry(title: String, sub: String, glyph: String, action: () -> Unit) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(panel, 14)
            setOnClickListener { action() }
        }
        val symbol = TextView(this).apply {
            text = glyph; textSize = 23f; setTextColor(accent); gravity = Gravity.CENTER
            background = rounded(panel2, 12)
        }
        item.addView(symbol, LinearLayout.LayoutParams(dp(46), dp(46)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        names.addView(label(title, 15f, mainText, true))
        names.addView(label(sub, 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
        item.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        item.addView(label("›", 24f, muted))
        page.addView(item, match().bottom(9))
    }

    private fun actionButton(text: String, primary: Boolean, action: () -> Unit) {
        val b = TextView(this).apply {
            this.text = text; gravity = Gravity.CENTER; textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (primary) Color.rgb(4, 20, 19) else mainText)
            background = rounded(if (primary) accent else panel2, 12)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnClickListener { action() }
        }
        page.addView(b, match().bottom(9))
    }

    private fun smallAction(text: String, action: () -> Unit): View = TextView(this).apply {
        this.text = text; gravity = Gravity.CENTER; textSize = 13f; setTextColor(accent)
        background = rounded(panel2, 10); setOnClickListener { action() }
    }

    private fun addSeek(parent: LinearLayout, title: String, key: String, min: Int, max: Int, default: Int, suffix: String) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(5)) }
        val label = label("", 13f, mainText)
        val seek = SeekBar(this).apply {
            this.max = max - min
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(accent)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(line)
        }
        fun update(value: Int) { label.text = "$title     $value$suffix" }
        val initial = prefs.getInt(key, default).coerceIn(min, max)
        seek.progress = initial - min; update(initial)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress + min; update(value)
                prefs.edit().putInt(key, value).apply()
                if (fromUser) HoleLightAccessibilityService.requestRefresh()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        wrap.addView(label)
        wrap.addView(seek, LinearLayout.LayoutParams(-1, dp(34)))
        parent.addView(wrap, match())
    }

    private fun saveSettings() {
        val saved = prefs.edit()
            .putInt(RingOverlayView.KEY_DIAMETER, prefs.getInt(RingOverlayView.KEY_DIAMETER, RingOverlayView.DEFAULT_DIAMETER))
            .putInt(RingOverlayView.KEY_BRIGHTNESS, prefs.getInt(RingOverlayView.KEY_BRIGHTNESS, RingOverlayView.DEFAULT_BRIGHTNESS))
            .putInt(RingOverlayView.KEY_X_OFFSET, prefs.getInt(RingOverlayView.KEY_X_OFFSET, 0))
            .putInt(RingOverlayView.KEY_Y_POSITION, prefs.getInt(RingOverlayView.KEY_Y_POSITION, RingOverlayView.DEFAULT_Y_POSITION))
            .putBoolean(RingOverlayView.KEY_AUTO_CAMERA, prefs.getBoolean(RingOverlayView.KEY_AUTO_CAMERA, true))
            .putInt(RingOverlayView.KEY_ICON_SIZE, prefs.getInt(RingOverlayView.KEY_ICON_SIZE, RingOverlayView.DEFAULT_ICON_SIZE))
            .putInt(RingOverlayView.KEY_ICON_GAP, prefs.getInt(RingOverlayView.KEY_ICON_GAP, RingOverlayView.DEFAULT_ICON_GAP))
            .commit()
        Toast.makeText(this, if (saved) "设置已保存" else "保存失败，请重试", Toast.LENGTH_SHORT).show()
        HoleLightAccessibilityService.requestRefresh()
    }

    private fun resetSettings() {
        prefs.edit()
            .putInt(RingOverlayView.KEY_DIAMETER, RingOverlayView.DEFAULT_DIAMETER)
            .putInt(RingOverlayView.KEY_BRIGHTNESS, RingOverlayView.DEFAULT_BRIGHTNESS)
            .putInt(RingOverlayView.KEY_X_OFFSET, 0)
            .putInt(RingOverlayView.KEY_Y_POSITION, RingOverlayView.DEFAULT_Y_POSITION)
            .putBoolean(RingOverlayView.KEY_AUTO_CAMERA, true)
            .putInt(RingOverlayView.KEY_ICON_SIZE, RingOverlayView.DEFAULT_ICON_SIZE)
            .putInt(RingOverlayView.KEY_ICON_GAP, RingOverlayView.DEFAULT_ICON_GAP)
            .apply()
        showHome()
        HoleLightAccessibilityService.requestRefresh()
        Toast.makeText(this, "已恢复默认设置", Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, true).apply()
        if (::previewButton.isInitialized && currentPage == "home") updatePreviewButton()
        HoleLightAccessibilityService.requestRefresh()
    }

    override fun onStop() {
        prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, false).apply()
        HoleLightAccessibilityService.requestRefresh()
        super.onStop()
    }

    private fun updatePreviewButton() {
        if (!::previewButton.isInitialized) return
        previewButton.text = if (prefs.getBoolean(KEY_PREVIEW_ENABLED, true)) "●  预览已开启   ·   点击隐藏" else "○  预览已关闭   ·   点击显示"
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun LinearLayout.LayoutParams.bottom(v: Int) = apply { bottomMargin = dp(v) }
    private fun LinearLayout.LayoutParams.top(v: Int) = apply { topMargin = dp(v) }

    companion object { private const val KEY_PREVIEW_ENABLED = "preview_enabled" }
}
