package com.holelight.aod

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class HoleLightNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        publishActive()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        publishActive()
    }

    private fun publishActive() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        val allowed = prefs.getStringSet(KEY_ALLOWED_PACKAGES, null)?.toSet()

        // B 规则：以系统当前仍未清除的通知为准。
        // 同一应用无论有多少条通知只保留一个图标；常驻通知仍过滤。
        // 超过 6 个应用时按最近通知时间排序，显示最近活跃的 6 个应用。
        val packages = activeNotifications
            ?.asSequence()
            ?.filter { !it.isOngoing && it.packageName != packageName }
            ?.filter { allowed == null || allowed.contains(it.packageName) }
            ?.sortedByDescending { it.postTime }
            ?.map { it.packageName }
            ?.distinct()
            ?.take(RingOverlayView.MAX_ICONS)
            ?.toList()
            ?: emptyList()

        prefs.edit()
            .putString("notification_packages", packages.joinToString("|"))
            .apply()
        HoleLightAccessibilityService.requestRefresh()
    }

    companion object {
        private const val KEY_ALLOWED_PACKAGES = "allowed_notification_packages"

        @Volatile private var current: HoleLightNotificationListener? = null

        fun refreshFromSystem() {
            current?.runCatchingPublish()
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        current = this
        publishActive()
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    private fun runCatchingPublish() {
        runCatching { publishActive() }
    }
}
