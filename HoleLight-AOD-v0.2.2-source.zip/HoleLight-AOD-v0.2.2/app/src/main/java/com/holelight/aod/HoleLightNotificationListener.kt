package com.holelight.aod

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class HoleLightNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        publishActive()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        publishActive()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        publishActive()
    }

    private fun publishActive() {
        val packages = activeNotifications
            ?.asSequence()
            ?.filter { !it.isOngoing && it.packageName != packageName }
            ?.map { it.packageName }
            ?.distinct()
            ?.take(RingOverlayView.MAX_ICONS)
            ?.toList()
            ?: emptyList()

        getSharedPreferences("holelight", MODE_PRIVATE).edit()
            .putString("notification_packages", packages.joinToString("|"))
            .apply()
        HoleLightAccessibilityService.requestRefresh()
    }
}
