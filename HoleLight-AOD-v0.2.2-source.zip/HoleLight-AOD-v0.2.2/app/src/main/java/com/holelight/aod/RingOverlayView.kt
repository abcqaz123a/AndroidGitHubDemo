package com.holelight.aod

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.view.View

class RingOverlayView(context: Context) : View(context) {
    private val prefs = context.getSharedPreferences("holelight", Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var icons: List<Drawable> = emptyList()

    fun refreshIcons() {
        val names = prefs.getString("notification_packages", "").orEmpty()
            .split("|").filter { it.isNotBlank() }.distinct().take(MAX_ICONS)
        icons = names.mapNotNull {
            runCatching { context.packageManager.getApplicationIcon(it) }.getOrNull()
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val diameter = prefs.getInt(KEY_DIAMETER, DEFAULT_DIAMETER).coerceIn(24, 180) * d
        val brightness = prefs.getInt(KEY_BRIGHTNESS, DEFAULT_BRIGHTNESS).coerceIn(20, 100) / 100f
        val xOffset = prefs.getInt(KEY_X_OFFSET, 0).coerceIn(-200, 200) * d
        val yPosition = prefs.getInt(KEY_Y_POSITION, DEFAULT_Y_POSITION).coerceIn(0, 600) * d
        val cx = width * .5f + xOffset
        val cy = yPosition
        val radius = diameter * .5f

        val colors = intArrayOf(
            0xFFFF3434.toInt(), 0xFFFFA52D.toInt(), 0xFFE9F33A.toInt(),
            0xFF32E58A.toInt(), 0xFF28C7F4.toInt(), 0xFF625CFF.toInt(),
            0xFFCB4BFF.toInt(), 0xFFFF348D.toInt(), 0xFFFF3434.toInt()
        )
        paint.alpha = (255 * brightness).toInt()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (3.2f * d).coerceAtMost(diameter * .09f)
        paint.shader = SweepGradient(cx, cy, colors, null)
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null
        paint.alpha = 255

        if (icons.isEmpty()) return
        val iconSize = (diameter * .38f).coerceIn(18f * d, 30f * d)
        val gap = 8f * d
        val total = icons.size * iconSize + (icons.size - 1) * gap
        var x = cx - total / 2f
        val top = cy + radius + 16f * d
        icons.forEach { icon ->
            icon.alpha = (255 * brightness).toInt()
            icon.setBounds(x.toInt(), top.toInt(), (x + iconSize).toInt(), (top + iconSize).toInt())
            icon.draw(canvas)
            x += iconSize + gap
        }
    }

    companion object {
        const val KEY_DIAMETER = "ring_diameter"
        const val KEY_BRIGHTNESS = "ring_brightness"
        const val KEY_X_OFFSET = "ring_x_offset"
        const val KEY_Y_POSITION = "ring_y_position"
        const val DEFAULT_DIAMETER = 54
        const val DEFAULT_BRIGHTNESS = 80
        const val DEFAULT_Y_POSITION = 75
        const val MAX_ICONS = 6
    }
}
