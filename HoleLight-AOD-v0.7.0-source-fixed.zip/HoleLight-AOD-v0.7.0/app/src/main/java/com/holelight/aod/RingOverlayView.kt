package com.holelight.aod

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class RingOverlayView(context: Context) : View(context) {
    private val prefs = context.getSharedPreferences("holelight", Context.MODE_PRIVATE)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gradientMatrix = Matrix()
    private val handler = Handler(Looper.getMainLooper())
    private var icons: List<Drawable> = emptyList()
    private var lastPackageSnapshot: String? = null
    private var animationPhase = 0f
    private var animator: ValueAnimator? = null
    private var runningStyle = -1
    private var runningSpeed = -1
    private var burnInTick: Runnable? = null

    private val colors = intArrayOf(
        0xFFFF3434.toInt(), 0xFFFFA52D.toInt(), 0xFFE9F33A.toInt(),
        0xFF32E58A.toInt(), 0xFF28C7F4.toInt(), 0xFF625CFF.toInt(),
        0xFFCB4BFF.toInt(), 0xFFFF348D.toInt(), 0xFFFF3434.toInt()
    )

    fun refreshIcons() {
        ensureAnimation()
        val snapshot = prefs.getString("notification_packages", "").orEmpty()
        if (snapshot == lastPackageSnapshot) return
        lastPackageSnapshot = snapshot
        val names = snapshot.split("|").filter { it.isNotBlank() }.distinct().take(MAX_ICONS)
        icons = names.mapNotNull { runCatching { context.packageManager.getApplicationIcon(it) }.getOrNull() }
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ensureAnimation()
        scheduleBurnInTick()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        burnInTick?.let(handler::removeCallbacks)
        burnInTick = null
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) {
            ensureAnimation()
            scheduleBurnInTick()
        } else {
            animator?.cancel()
            animator = null
            burnInTick?.let(handler::removeCallbacks)
            burnInTick = null
        }
    }

    private fun ensureAnimation() {
        val style = prefs.getInt(KEY_STYLE, STYLE_STATIC).coerceIn(STYLE_STATIC, STYLE_DUAL_CHASE)
        val speed = prefs.getInt(KEY_SPEED, DEFAULT_SPEED).coerceIn(1, 10)
        if (style == runningStyle && speed == runningSpeed &&
            ((style == STYLE_STATIC || animator?.isRunning == true) || visibility != VISIBLE)) return

        animator?.cancel()
        animator = null
        runningStyle = style
        runningSpeed = speed
        if (style == STYLE_STATIC || !isAttachedToWindow || visibility != VISIBLE) {
            invalidate()
            return
        }

        val duration = (14000L - (speed - 1) * 1250L).coerceAtLeast(1500L)
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            this.duration = duration
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                animationPhase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun scheduleBurnInTick() {
        burnInTick?.let(handler::removeCallbacks)
        if (!isAttachedToWindow || visibility != VISIBLE) return
        val task = object : Runnable {
            override fun run() {
                if (!isAttachedToWindow || visibility != VISIBLE) return
                invalidate()
                val interval = prefs.getInt(KEY_BURN_INTERVAL, DEFAULT_BURN_INTERVAL).coerceIn(1, 10)
                handler.postDelayed(this, 30_000L.coerceAtMost(interval * 15_000L))
            }
        }
        burnInTick = task
        handler.postDelayed(task, 30_000L)
    }

    private fun burnInOffsetPx(): Pair<Float, Float> {
        if (!prefs.getBoolean(KEY_BURN_ENABLED, true)) return 0f to 0f
        val intervalMs = prefs.getInt(KEY_BURN_INTERVAL, DEFAULT_BURN_INTERVAL).coerceIn(1, 10) * 60_000L
        val step = (SystemClock.elapsedRealtime() / intervalMs).toInt()
        // Eight very small physical-pixel offsets; the camera aperture remains visually aligned.
        val offsets = arrayOf(
            0f to 0f, 1f to 0f, 1f to 1f, 0f to 1f,
            -1f to 1f, -1f to 0f, -1f to -1f, 0f to -1f
        )
        return offsets[step % offsets.size]
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val diameter = prefs.getInt(KEY_DIAMETER, DEFAULT_DIAMETER).coerceIn(24, 180) * d
        val userBrightness = prefs.getInt(KEY_BRIGHTNESS, DEFAULT_BRIGHTNESS).coerceIn(20, 100)
        val burnCap = prefs.getInt(KEY_BURN_BRIGHTNESS_CAP, DEFAULT_BURN_BRIGHTNESS_CAP).coerceIn(20, 100)
        val brightness = (if (prefs.getBoolean(KEY_BURN_ENABLED, true)) minOf(userBrightness, burnCap) else userBrightness) / 100f
        val xOffset = prefs.getInt(KEY_X_OFFSET, 0).coerceIn(-300, 300) * d
        val yOffset = prefs.getInt(KEY_Y_POSITION, DEFAULT_Y_POSITION).coerceIn(-200, 400) * d
        val radius = diameter * .5f
        val autoCamera = prefs.getBoolean(KEY_AUTO_CAMERA, true)
        val cutoutRect = if (autoCamera && android.os.Build.VERSION.SDK_INT >= 28) runCatching {
            rootWindowInsets?.displayCutout?.boundingRects?.filter { it.top <= height * .25f && it.width() > 0 && it.height() > 0 }
                ?.minByOrNull { abs((it.left + it.right) / 2f - width / 2f) }
        }.getOrNull() else null
        val baseCx = cutoutRect?.let { (it.left + it.right) / 2f } ?: width / 2f
        val baseCy = cutoutRect?.let { (it.top + it.bottom) / 2f } ?: 100f * d
        val (shiftX, shiftY) = burnInOffsetPx()
        val cx = baseCx + xOffset + shiftX
        val cy = baseCy + yOffset + shiftY
        val style = prefs.getInt(KEY_STYLE, STYLE_STATIC).coerceIn(STYLE_STATIC, STYLE_DUAL_CHASE)
        val wave = ((sin(Math.toRadians(animationPhase.toDouble())) + 1.0) / 2.0).toFloat()
        val heartbeat = when {
            wave < .18f -> .42f + wave * 2.5f
            wave < .34f -> 1f
            wave < .52f -> .48f
            else -> .48f + (wave - .52f) * 1.08f
        }
        val alphaFactor = when (style) {
            STYLE_BREATHING -> .32f + .68f * wave
            STYLE_PULSE -> .55f + .45f * wave
            STYLE_HEARTBEAT -> heartbeat
            else -> 1f
        }
        val strokeBase = (3.2f * d).coerceAtMost(diameter * .09f)
        val burnRadiusNudge = if (prefs.getBoolean(KEY_BURN_ENABLED, true)) ((SystemClock.elapsedRealtime() / 300_000L) % 3L - 1L).toFloat() else 0f

        val save = canvas.save()
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.shader = SweepGradient(cx, cy, colors, null)

        when (style) {
            STYLE_SPIN -> {
                paint.alpha = (255 * brightness).toInt()
                paint.strokeWidth = strokeBase * 1.15f
                gradientMatrix.setRotate(animationPhase, cx, cy)
                (paint.shader as? SweepGradient)?.setLocalMatrix(gradientMatrix)
                canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), animationPhase, 112f, false, paint)
                canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), animationPhase+180f, 34f, false, paint)
            }
            STYLE_SEGMENT_BLINK -> {
                paint.strokeWidth = strokeBase * 1.2f
                val segmentCount = 12
                for (i in 0 until segmentCount) {
                    val phaseOn = ((i + (animationPhase / 30f).toInt()) % 3) != 0
                    paint.alpha = if (phaseOn) (255 * brightness).toInt() else (55 * brightness).toInt()
                    paint.color = colors[i % (colors.size - 1)]
                    paint.shader = null
                    canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), i * 30f + 2f, 24f, false, paint)
                }
            }
            STYLE_DUAL_ORBIT -> {
                paint.alpha = (235 * brightness).toInt()
                paint.strokeWidth = strokeBase
                canvas.drawCircle(cx, cy, radius + burnRadiusNudge, paint)
                paint.alpha = (170 * brightness).toInt()
                paint.strokeWidth = (strokeBase * .55f).coerceAtLeast(1f)
                canvas.drawCircle(cx, cy, radius - 4f * d + burnRadiusNudge, paint)
            }
            STYLE_SPARKLE -> {
                paint.alpha = (210 * brightness).toInt()
                paint.strokeWidth = strokeBase
                canvas.drawCircle(cx, cy, radius, paint)
                paint.style = Paint.Style.FILL
                paint.shader = null
                for (i in 0 until 8) {
                    val angle = Math.toRadians((i * 45f + animationPhase * 1.5f).toDouble())
                    val r = radius + sin(Math.toRadians((animationPhase * 2f + i * 45f).toDouble())).toFloat() * 1.2f * d
                    val x = cx + cos(angle).toFloat() * r
                    val y = cy + sin(angle).toFloat() * r
                    paint.color = colors[i % (colors.size - 1)]
                    paint.alpha = (brightness * (130 + 125 * ((sin(Math.toRadians((animationPhase + i * 45f).toDouble())).toFloat() + 1f) / 2f))).toInt().coerceIn(0,255)
                    canvas.drawCircle(x, y, (1.1f + wave) * d, paint)
                }
            }
            STYLE_SPECTRUM -> {
                paint.shader = null
                paint.strokeWidth = strokeBase * 1.35f
                for (i in 0 until 24) {
                    paint.color = colors[i % (colors.size - 1)]
                    paint.alpha = (255 * brightness * (0.65f + 0.35f * ((sin(Math.toRadians((animationPhase + i * 18f).toDouble())).toFloat() + 1f) / 2f))).toInt()
                    canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), i * 15f + 1.5f, 12f, false, paint)
                }
            }
            STYLE_EDGE_GLOW -> {
                paint.shader = SweepGradient(cx, cy, colors, null)
                for (i in 3 downTo 0) {
                    paint.alpha = (brightness * (42 + i * 48) * alphaFactor).toInt().coerceIn(0,255)
                    paint.strokeWidth = strokeBase * (1f + i * .65f)
                    canvas.drawCircle(cx, cy, radius + burnRadiusNudge, paint)
                }
            }
            STYLE_DUAL_CHASE -> {
                paint.alpha = (190 * brightness).toInt()
                paint.strokeWidth = strokeBase * .65f
                canvas.drawCircle(cx, cy, radius, paint)
                paint.style = Paint.Style.FILL
                paint.shader = null
                for (i in 0..1) {
                    val angle = Math.toRadians(animationPhase.toDouble() + i * 180.0)
                    paint.color = if (i == 0) 0xFFFFFFFF.toInt() else 0xFF6FFFF0.toInt()
                    paint.alpha = (255 * brightness).toInt()
                    canvas.drawCircle(cx + cos(angle).toFloat() * radius, cy + sin(angle).toFloat() * radius, 2.2f * d, paint)
                }
            }
            else -> {
                paint.alpha = (255 * brightness * alphaFactor).toInt().coerceIn(0,255)
                paint.strokeWidth = when (style) {
                    STYLE_PULSE -> (2.5f + 1.8f * wave) * d
                    else -> strokeBase
                }.coerceAtMost(diameter * .09f)
                if (style == STYLE_FLOW) {
                    gradientMatrix.setRotate(animationPhase, cx, cy)
                    (paint.shader as? SweepGradient)?.setLocalMatrix(gradientMatrix)
                }
                canvas.drawCircle(cx, cy, radius + burnRadiusNudge, paint)
            }
        }
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.alpha = 255

        if (icons.isNotEmpty()) {
            val iconScale = prefs.getInt(KEY_ICON_SIZE, DEFAULT_ICON_SIZE).coerceIn(60, 140) / 100f
            val gapDp = prefs.getInt(KEY_ICON_GAP, DEFAULT_ICON_GAP).coerceIn(2, 20)
            val requestedSize = (diameter * .38f).coerceIn(18f * d, 30f * d) * iconScale
            val gap = gapDp * d
            val availableWidth = (width - 32f * d).coerceAtLeast(1f)
            val fittedSize = ((availableWidth - (icons.size - 1) * gap) / icons.size).coerceAtLeast(12f * d)
            val iconSize = minOf(requestedSize, fittedSize)
            val actualGap = if (icons.size > 1) minOf(gap, ((availableWidth - icons.size * iconSize) / (icons.size - 1)).coerceAtLeast(1f * d)) else 0f
            val total = icons.size * iconSize + (icons.size - 1) * actualGap
            var x = (width - total) / 2f + shiftX
            val top = cy + radius + 16f * d
            icons.forEach { icon ->
                icon.alpha = (255 * brightness).toInt()
                icon.setBounds(x.toInt(), top.toInt(), (x + iconSize).toInt(), (top + iconSize).toInt())
                icon.draw(canvas)
                x += iconSize + actualGap
            }
        }
        canvas.restoreToCount(save)
    }

    companion object {
        const val KEY_DIAMETER = "ring_diameter"
        const val KEY_BRIGHTNESS = "ring_brightness"
        const val KEY_X_OFFSET = "ring_x_offset"
        const val KEY_Y_POSITION = "ring_y_position"
        const val KEY_AUTO_CAMERA = "auto_camera_alignment"
        const val KEY_ICON_SIZE = "notification_icon_size"
        const val KEY_ICON_GAP = "notification_icon_gap"
        const val KEY_STYLE = "ring_style"
        const val KEY_SPEED = "ring_animation_speed"
        const val KEY_BURN_ENABLED = "burn_in_protection_enabled"
        const val KEY_BURN_INTERVAL = "burn_in_shift_interval_minutes"
        const val KEY_BURN_BRIGHTNESS_CAP = "burn_in_brightness_cap"
        const val STYLE_STATIC = 0
        const val STYLE_FLOW = 1
        const val STYLE_BREATHING = 2
        const val STYLE_PULSE = 3
        const val STYLE_HEARTBEAT = 4
        const val STYLE_SPIN = 5
        const val STYLE_SEGMENT_BLINK = 6
        const val STYLE_DUAL_ORBIT = 7
        const val STYLE_SPARKLE = 8
        const val STYLE_SPECTRUM = 9
        const val STYLE_EDGE_GLOW = 10
        const val STYLE_DUAL_CHASE = 11
        const val DEFAULT_SPEED = 5
        const val DEFAULT_ICON_SIZE = 100
        const val DEFAULT_ICON_GAP = 8
        const val DEFAULT_DIAMETER = 30
        const val DEFAULT_BRIGHTNESS = 80
        const val DEFAULT_Y_POSITION = 3
        const val DEFAULT_BURN_INTERVAL = 2
        const val DEFAULT_BURN_BRIGHTNESS_CAP = 70
        const val MAX_ICONS = 8
    }
}
