package com.holelight.aod

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("holelight", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var previewButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMainScreen()
    }

    private fun newPage(title: String) {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 28)
            setBackgroundColor(0xFF101114.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)
        text(title, 25f)
    }

    private fun showMainScreen() {
        newPage("HoleLight")
        text("RGB 通知圆环", 14f, 0xFF9DA3AE.toInt())

        previewButton = Button(this).apply {
            setOnClickListener {
                val enabled = !prefs.getBoolean(KEY_PREVIEW_ENABLED, true)
                prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, enabled).apply()
                updatePreviewButton()
                HoleLightAccessibilityService.requestRefresh()
            }
        }
        root.addView(previewButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 8; bottomMargin = 10 })
        updatePreviewButton()

        val autoCamera = CheckBox(this).apply {
            text = "自动对准前置摄像头"
            setTextColor(0xFFE0E2E8.toInt())
            textSize = 15f
            isChecked = prefs.getBoolean(RingOverlayView.KEY_AUTO_CAMERA, true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean(RingOverlayView.KEY_AUTO_CAMERA, checked).apply()
                HoleLightAccessibilityService.requestRefresh()
            }
        }
        root.addView(autoCamera)

        addSeek("圆环直径", RingOverlayView.KEY_DIAMETER, 24, 180,
            RingOverlayView.DEFAULT_DIAMETER, " dp")
        addSeek("圆环亮度", RingOverlayView.KEY_BRIGHTNESS, 20, 100,
            RingOverlayView.DEFAULT_BRIGHTNESS, "%")
        addSeek("水平位置", RingOverlayView.KEY_X_OFFSET, -300, 300, 0, " dp")
        addSeek("垂直位置", RingOverlayView.KEY_Y_POSITION, -200, 400,
            RingOverlayView.DEFAULT_Y_POSITION, " dp")
        addSeek("通知图标大小", RingOverlayView.KEY_ICON_SIZE, 60, 140,
            RingOverlayView.DEFAULT_ICON_SIZE, "%")
        addSeek("通知图标间距", RingOverlayView.KEY_ICON_GAP, 2, 20,
            RingOverlayView.DEFAULT_ICON_GAP, " dp")

        button("保存设置") {
            val saved = prefs.edit()
                .putInt(RingOverlayView.KEY_DIAMETER, prefs.getInt(RingOverlayView.KEY_DIAMETER, RingOverlayView.DEFAULT_DIAMETER))
                .putInt(RingOverlayView.KEY_BRIGHTNESS, prefs.getInt(RingOverlayView.KEY_BRIGHTNESS, RingOverlayView.DEFAULT_BRIGHTNESS))
                .putInt(RingOverlayView.KEY_X_OFFSET, prefs.getInt(RingOverlayView.KEY_X_OFFSET, 0))
                .putInt(RingOverlayView.KEY_Y_POSITION, prefs.getInt(RingOverlayView.KEY_Y_POSITION, RingOverlayView.DEFAULT_Y_POSITION))
                .putBoolean(RingOverlayView.KEY_AUTO_CAMERA, prefs.getBoolean(RingOverlayView.KEY_AUTO_CAMERA, true))
                .putInt(RingOverlayView.KEY_ICON_SIZE, prefs.getInt(RingOverlayView.KEY_ICON_SIZE, RingOverlayView.DEFAULT_ICON_SIZE))
                .putInt(RingOverlayView.KEY_ICON_GAP, prefs.getInt(RingOverlayView.KEY_ICON_GAP, RingOverlayView.DEFAULT_ICON_GAP))
                .commit()
            android.widget.Toast.makeText(this, if (saved) "设置已保存" else "保存失败，请重试", android.widget.Toast.LENGTH_SHORT).show()
            HoleLightAccessibilityService.requestRefresh()
        }
        button("恢复默认设置") {
            prefs.edit()
                .putInt(RingOverlayView.KEY_DIAMETER, RingOverlayView.DEFAULT_DIAMETER)
                .putInt(RingOverlayView.KEY_BRIGHTNESS, RingOverlayView.DEFAULT_BRIGHTNESS)
                .putInt(RingOverlayView.KEY_X_OFFSET, 0)
                .putInt(RingOverlayView.KEY_Y_POSITION, RingOverlayView.DEFAULT_Y_POSITION)
                .putBoolean(RingOverlayView.KEY_AUTO_CAMERA, true)
                .putInt(RingOverlayView.KEY_ICON_SIZE, RingOverlayView.DEFAULT_ICON_SIZE)
                .putInt(RingOverlayView.KEY_ICON_GAP, RingOverlayView.DEFAULT_ICON_GAP)
                .apply()
            showMainScreen()
            HoleLightAccessibilityService.requestRefresh()
        }
        button("菜单  ·  应用列表与权限设置") { showMenuScreen() }
    }

    private fun showMenuScreen() {
        newPage("菜单")
        button("应用列表") { showAppListScreen() }
        button("无障碍显示服务") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("通知读取权限") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("检查通知监听状态") {
            val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
                .orEmpty().contains(packageName)
            android.widget.Toast.makeText(this,
                if (enabled) "通知读取权限已开启" else "通知读取权限未开启",
                android.widget.Toast.LENGTH_LONG).show()
        }
        button("系统显示设置") { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        button("关于 HoleLight") { showAboutScreen() }
        button("返回首页") { showMainScreen() }
    }

    private fun showAppListScreen() {
        newPage("应用列表")
        button("返回菜单") { showMenuScreen() }
        buildAppFilterSection()
    }

    private fun showAboutScreen() {
        newPage("关于 HoleLight")
        text("版本 0.4.0", 15f, 0xFFB8BBC4.toInt())
        text("显示未清除通知对应的已允许应用图标；同一应用只显示一个图标，最多显示 8 个应用。", 14f, 0xFFE0E2E8.toInt())
        text("重要限制：第三方无障碍覆盖层不属于系统原生 AOD 内容。HyperOS 可能在真正低功耗 AOD 状态隐藏它；本应用不会点亮屏幕或伪装常亮 AOD。", 13f, 0xFF9DA3AE.toInt())
        button("返回菜单") { showMenuScreen() }
    }

    private fun buildAppFilterSection() {
        text("选择允许显示通知图标的应用", 14f, 0xFF9DA3AE.toInt())

        val pm = packageManager
        val density = resources.displayMetrics.density

        // 直接枚举当前用户已安装的软件包。
        // 不依赖 Launcher 查询结果，也不使用 FLAG_INSTALLED 过滤，
        // 避免部分 HyperOS ROM 对 queryIntentActivities/MATCH_ALL 的兼容差异。
        val packageReadResult = runCatching {
            @Suppress("DEPRECATION")
            pm.getInstalledApplications(0)
        }

        val installedApps = packageReadResult.getOrDefault(emptyList())
            .filter { it.packageName != packageName }
            .filter { appInfo ->
                runCatching {
                    // 过滤掉没有可显示应用标签/图标的异常包记录。
                    pm.getApplicationLabel(appInfo).isNotBlank()
                }.getOrDefault(false)
            }

        val apps = installedApps.sortedBy {
            runCatching { pm.getApplicationLabel(it).toString().lowercase() }
                .getOrDefault(it.packageName.lowercase())
        }


        val allowedKey = "allowed_notification_packages"
        val knownKey = "known_app_packages"
        val installedPackages = apps.map { it.packageName }.toSet()
        val hasKnownSnapshot = prefs.contains(knownKey)
        val knownPackages = (prefs.getStringSet(knownKey, emptySet()) ?: emptySet()).toMutableSet()
        val allowed = (prefs.getStringSet(allowedKey, emptySet()) ?: emptySet()).toMutableSet()

        if (!prefs.contains(allowedKey)) {
            allowed.addAll(installedPackages)
        } else if (hasKnownSnapshot) {
            allowed.addAll(installedPackages - knownPackages)
        }
        allowed.retainAll(installedPackages)
        prefs.edit()
            .putStringSet(allowedKey, allowed)
            .putStringSet(knownKey, installedPackages)
            .apply()

        val countLabel = TextView(this).apply {
            setTextColor(0xFFB8BBC4.toInt())
            textSize = 13f
        }
        val statusLabel = TextView(this).apply {
            setTextColor(0xFF9DA3AE.toInt())
            textSize = 12f
        }
        val search = EditText(this).apply {
            hint = "搜索应用名称或包名"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF858B96.toInt())
        }
        val onlyEnabled = CheckBox(this).apply {
            text = "只显示已开启的应用"
            setTextColor(0xFFE0E2E8.toInt())
        }
        val appContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        fun selectedPackages(): MutableSet<String> =
            (prefs.getStringSet(allowedKey, emptySet()) ?: emptySet()).toMutableSet()

        fun refreshCount() {
            val selected = selectedPackages()
            countLabel.text = "已开启 ${selected.size} / ${apps.size} 个应用"
            statusLabel.text = if (apps.isEmpty()) "暂未发现可管理的应用" else "仅显示仍有未清除通知的应用图标"
        }

        fun rebuildRows() {
            appContainer.removeAllViews()
            val selected = selectedPackages()
            val query = search.text.toString().trim().lowercase()
            val visibleApps = apps.filter { app ->
                val label = runCatching { pm.getApplicationLabel(app).toString() }.getOrDefault(app.packageName)
                val matchesSearch = query.isEmpty() ||
                    label.lowercase().contains(query) ||
                    app.packageName.lowercase().contains(query)
                val matchesEnabled = !onlyEnabled.isChecked || selected.contains(app.packageName)
                matchesSearch && matchesEnabled
            }

            visibleApps.forEach { app ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = android.view.Gravity.CENTER_VERTICAL
                    setPadding(4, (5 * density).toInt(), 4, (5 * density).toInt())
                }
                val icon = ImageView(this).apply {
                    val drawable = runCatching { pm.getApplicationIcon(app) }.getOrNull()
                    setImageDrawable(drawable)
                    layoutParams = LinearLayout.LayoutParams(
                        (36 * density).toInt(), (36 * density).toInt()
                    )
                }
                val check = CheckBox(this).apply {
                    text = runCatching { pm.getApplicationLabel(app).toString() }.getOrDefault(app.packageName)
                    setTextColor(0xFFE0E2E8.toInt())
                    isChecked = selected.contains(app.packageName)
                    setOnCheckedChangeListener { _, checked ->
                        val now = selectedPackages()
                        if (checked) now.add(app.packageName) else now.remove(app.packageName)
                        prefs.edit().putStringSet(allowedKey, now).apply()
                        refreshCount()
                        if (onlyEnabled.isChecked && !checked) rebuildRows()
                        HoleLightNotificationListener.refreshFromSystem()
                    }
                }
                row.addView(icon)
                row.addView(check, LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                ))
                appContainer.addView(row)
            }

            if (visibleApps.isEmpty()) {
                appContainer.addView(TextView(this).apply {
                    text = if (apps.isEmpty()) "没有读取到可管理的应用" else "没有匹配的应用"
                    setTextColor(0xFF9DA3AE.toInt())
                    setPadding(8, 16, 8, 16)
                })
            }
            refreshCount()
        }

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val selectAll = Button(this).apply {
            text = "一键全选"
            setOnClickListener {
                prefs.edit().putStringSet(allowedKey, installedPackages).apply()
                rebuildRows()
                HoleLightNotificationListener.refreshFromSystem()
            }
        }
        val disableAll = Button(this).apply {
            text = "一键全关闭"
            setOnClickListener {
                prefs.edit().putStringSet(allowedKey, emptySet()).apply()
                rebuildRows()
                HoleLightNotificationListener.refreshFromSystem()
            }
        }
        actions.addView(selectAll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(disableAll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { rebuildRows() }
            override fun afterTextChanged(s: Editable?) {}
        })
        onlyEnabled.setOnCheckedChangeListener { _, _ -> rebuildRows() }

        root.addView(countLabel)
        root.addView(statusLabel)
        root.addView(search, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        root.addView(onlyEnabled)
        root.addView(actions)
        root.addView(appContainer)
        rebuildRows()
    }

    override fun onResume() {
        super.onResume()
        // 每次进入设置界面自动开启预览，便于直接调整参数
        prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, true).apply()
        if (::previewButton.isInitialized) updatePreviewButton()
        HoleLightAccessibilityService.requestRefresh()
    }

    override fun onStop() {
        // 离开应用后关闭临时预览，不影响锁屏状态下的正常显示
        prefs.edit().putBoolean(KEY_PREVIEW_ENABLED, false).apply()
        HoleLightAccessibilityService.requestRefresh()
        super.onStop()
    }

    private fun updatePreviewButton() {
        val enabled = prefs.getBoolean(KEY_PREVIEW_ENABLED, true)
        previewButton.text = if (enabled) "圆环预览：已开启（点击隐藏）" else "圆环预览：已关闭（点击显示）"
    }

    private fun text(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) {
        root.addView(TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 10 })
    }

    private fun button(label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 7 })
    }

    companion object {
        private const val KEY_PREVIEW_ENABLED = "preview_enabled"
    }

    private fun addSeek(
        title: String, key: String, min: Int, max: Int, default: Int, suffix: String
    ) {
        val label = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
        }
        val seek = SeekBar(this).apply { this.max = max - min }
        fun updateLabel(value: Int) { label.text = "$title：$value$suffix" }
        val initial = prefs.getInt(key, default).coerceIn(min, max)
        seek.progress = initial - min
        updateLabel(initial)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress + min
                updateLabel(value)
                prefs.edit().putInt(key, value).apply()
                if (fromUser) HoleLightAccessibilityService.requestRefresh()
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })
        root.addView(label)
        root.addView(seek, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 12 })
    }
}
