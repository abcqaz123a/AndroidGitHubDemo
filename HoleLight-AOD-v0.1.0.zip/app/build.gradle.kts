plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.holelight.aod"
    compileSdk = 35
    defaultConfig { applicationId = "com.holelight.aod"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
    kotlinOptions { jvmTarget = "17" }
}
