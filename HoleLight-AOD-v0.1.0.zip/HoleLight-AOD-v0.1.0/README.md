# HoleLight AOD — 实验版 0.1.0

目标设备：小米 15S Pro / HyperOS 4.0 / 未 Root。

## 本版功能
- AccessibilityService 使用 `TYPE_ACCESSIBILITY_OVERLAY` 在锁屏界面尝试绘制静态 RGB 彩虹圆环。
- NotificationListenerService 读取活动通知的应用包名，并在圆环下方显示最多 4 个应用图标。
- 不申请普通悬浮窗权限，不持有 WakeLock，不主动点亮屏幕，不上传通知数据。
- GitHub Actions 自动构建 Debug APK。

## 关键限制
Android 第三方无障碍覆盖层不保证能显示在真正低功耗 AOD/Doze 显示路径上。HyperOS 可能在熄屏或 AOD 状态隐藏第三方覆盖层。本版本用于验证锁屏和真正 AOD 两种状态的表现。若只在锁屏可见、进入真正 AOD 后消失，说明这条普通 APK 覆盖层路线无法实现真正系统级 AOD；不能用保持屏幕常亮来伪装。

## GitHub 云端编译
最简单方式：把 `HoleLight-AOD-v0.1.0.zip` 这个压缩包上传到仓库根目录并提交。Actions 会自动解压并构建。也可以先解压，再把 ZIP 内所有文件/文件夹直接上传到仓库根目录。成功后打开最新一次 `Build HoleLight APK`，在 Artifacts 下载 `HoleLight-debug-apk`，解压得到 `app-debug.apk`。

## 手机上测试
1. 安装 APK 并打开 HoleLight。
2. 点击“开启无障碍显示服务”，在系统无障碍设置中启用 HoleLight。
3. 点击“开启通知读取权限”，在通知使用权页面允许 HoleLight。
4. 确认系统自身 AOD 已开启。
5. 返回桌面，按电源键锁屏，观察圆环。
6. 等待系统进入真正 AOD，再观察圆环是否保留。

## 已知待完善
圆环暂按屏幕顶部中心 75dp 放置，未根据相机孔实测校准；暂未提供尺寸/位置/亮度/防烧屏位移设置。
