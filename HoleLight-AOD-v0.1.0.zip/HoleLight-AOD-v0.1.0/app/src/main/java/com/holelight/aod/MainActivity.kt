package com.holelight.aod

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 32, 28, 24); setBackgroundColor(0xFF101114.toInt()) }
        fun addText(s: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) { root.addView(TextView(this).apply { text=s; textSize=size; setTextColor(color) }) }
        fun addButton(s: String, action: () -> Unit) { root.addView(Button(this).apply { text=s; setOnClickListener { action() } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin=10 }) }
        addText("HoleLight", 30f)
        addText("AuraDisplay 风格通知圆环 · 实验版 0.1.0", 15f, 0xFFB8BBC4.toInt())
        addText("\n本版本使用无障碍覆盖层尝试在锁屏上绘制圆环，并读取通知应用图标。\n\n重要：Android/HyperOS 通常会在真正息屏或低功耗 AOD 时隐藏第三方覆盖层。此实验不会强制点亮屏幕，也不会使用常亮屏幕伪装 AOD。", 15f, 0xFFE0E2E8.toInt())
        addButton("① 开启无障碍显示服务") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        addButton("② 开启通知读取权限") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        addButton("③ 打开系统显示设置") { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
        addText("\n授权前两项后，返回桌面并按电源键锁屏。先观察锁屏界面，再等待系统进入真正 AOD，检查圆环是否仍可见。\n\n隐私：通知访问仅用于读取发布通知的应用包名/图标；不上传通知内容或数据。", 14f, 0xFF9DA3AE.toInt())
        setContentView(root)
    }
}
