package com.holelight.aod

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.view.View

class RingOverlayView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var icons: List<Drawable> = emptyList()
    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null); refreshIcons() }
    fun refreshIcons() {
        val names = context.getSharedPreferences("holelight", Context.MODE_PRIVATE).getString("notification_packages", "").orEmpty().split("|").filter { it.isNotBlank() }.take(4)
        icons = names.mapNotNull { runCatching { context.packageManager.getApplicationIcon(it) }.getOrNull() }
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val cx = width * .5f; val cy = 75f * d; val radius = 27f * d
        val colors = intArrayOf(0xFFFF3434.toInt(),0xFFFFA52D.toInt(),0xFFE9F33A.toInt(),0xFF32E58A.toInt(),0xFF28C7F4.toInt(),0xFF625CFF.toInt(),0xFFCB4BFF.toInt(),0xFFFF348D.toInt(),0xFFFF3434.toInt())
        paint.style=Paint.Style.STROKE; paint.strokeWidth=3.2f*d; paint.shader=SweepGradient(cx,cy,colors,null); canvas.drawCircle(cx,cy,radius,paint); paint.shader=null
        val sz=22f*d; val gap=9f*d; val total=icons.size*sz+maxOf(0,icons.size-1)*gap; var x=cx-total/2f; val top=cy+radius+20f*d
        icons.forEach { it.setBounds(x.toInt(),top.toInt(),(x+sz).toInt(),(top+sz).toInt()); it.draw(canvas); x+=sz+gap }
    }
}
