package com.holelight.aod

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.app.KeyguardManager
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class HoleLightAccessibilityService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var overlay: RingOverlayView? = null
    private lateinit var keyguard: KeyguardManager
    private val main = Handler(Looper.getMainLooper())
    override fun onServiceConnected() { super.onServiceConnected(); instance = this; wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager; keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager; refresh() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { main.post { refresh() } }
    override fun onInterrupt() {}
    private fun attach() {
        if (overlay != null) return
        val v = RingOverlayView(this)
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        runCatching { wm?.addView(v, lp); overlay = v }
    }
    private fun refresh() {
        if (!::keyguard.isInitialized || !keyguard.isKeyguardLocked) {
            overlay?.let { runCatching { wm?.removeView(it) } }
            overlay = null
            return
        }
        if (overlay == null) attach()
        overlay?.refreshIcons()
        overlay?.invalidate()
    }
    override fun onDestroy() { overlay?.let { runCatching { wm?.removeView(it) } }; overlay=null; instance=null; super.onDestroy() }
    companion object { @Volatile private var instance: HoleLightAccessibilityService? = null; fun requestRefresh() { instance?.main?.post { instance?.refresh() } } }
}
