package com.holelight.aod

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class HoleLightNotificationListener : NotificationListenerService() {

    private data class Notice(
        val key: String,
        val packageName: String,
        val postTime: Long,
        val ongoing: Boolean
    )

    private val notices = LinkedHashMap<String, Notice>()

    override fun onListenerConnected() {
        super.onListenerConnected()
        current = this
        syncFromSystem()
    }

    override fun onListenerDisconnected() {
        if (current === this) current = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        notices[sbn.key] = Notice(
            key = sbn.key,
            packageName = sbn.packageName,
            postTime = sbn.postTime,
            ongoing = sbn.isOngoing
        )
        publishActive()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        notices.remove(sbn.key)
        // 系统通知组更新/摘要通知移除时，以系统快照校准缓存。
        syncFromSystem()
    }

    private fun syncFromSystem() {
        runCatching {
            notices.clear()
            getActiveNotifications()?.forEach { sbn ->
                notices[sbn.key] = Notice(
                    key = sbn.key,
                    packageName = sbn.packageName,
                    postTime = sbn.postTime,
                    ongoing = sbn.isOngoing
                )
            }
        }
        publishActive()
    }

    private fun publishActive() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        val allowed = prefs.getStringSet(KEY_ALLOWED_PACKAGES, emptySet())?.toSet().orEmpty()

        // B 规则：所有尚未从系统通知栏清除的通知对应应用。
        // 同一应用去重；过滤常驻通知；超过 6 个应用时按最近通知排序。
        val packages = notices.values
            .asSequence()
            .filter { !it.ongoing && it.packageName != packageName }
            .filter { allowed.contains(it.packageName) }
            .sortedByDescending { it.postTime }
            .map { it.packageName }
            .distinct()
            .take(RingOverlayView.MAX_ICONS)
            .toList()

        prefs.edit()
            .putString("notification_packages", packages.joinToString("|"))
            .putInt("active_notification_count", notices.size)
            .apply()

        HoleLightAccessibilityService.requestRefresh()
    }

    companion object {
        private const val KEY_ALLOWED_PACKAGES = "allowed_notification_packages"
        @Volatile private var current: HoleLightNotificationListener? = null

        fun refreshFromSystem() {
            current?.let { service -> runCatching { service.syncFromSystem() } }
        }
    }

    override fun onDestroy() {
        if (current === this) current = null
        notices.clear()
        super.onDestroy()
    }
}
