package com.holelight.aod

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.view.accessibility.AccessibilityEvent

class HoleLightAccessibilityService : AccessibilityService() {
    private var wm: WindowManager? = null
    private var overlay: RingOverlayView? = null
    private var keyguard: KeyguardManager? = null
    private var power: PowerManager? = null
    private val main = Handler(Looper.getMainLooper())
    private val refreshTask = Runnable { refresh() }
    private val retryTask = Runnable { refresh() }
    private val watchdogTask = Runnable { runWatchdog() }
    private val pendingRefreshes = mutableSetOf<Runnable>()
    private var refreshGeneration = 0
    private var receiverRegistered = false
    private var attachRetryCount = 0
    private var lastNotificationSyncAt = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // 不主动移除窗口。屏幕关闭期间 Android/HyperOS 可能暂停绘制，
                    // 后续由屏幕点亮事件和看护任务检查窗口是否仍然有效。
                    scheduleWatchdog(15_000L)
                }
                Intent.ACTION_SCREEN_ON -> {
                    attachRetryCount = 0
                    scheduleRefreshBurst()
                    scheduleWatchdog(1_200L)
                }
                Intent.ACTION_USER_PRESENT -> {
                    scheduleRefresh(100L)
                    scheduleWatchdog(2_000L)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        power = getSystemService(Context.POWER_SERVICE) as PowerManager
        registerScreenReceiver()
        attachRetryCount = 0
        scheduleRefreshBurst()
        scheduleWatchdog(1_500L)
    }

    private fun registerScreenReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(screenReceiver, filter)
            }
            receiverRegistered = true
        }
    }

    // 不读取窗口内容，不依赖高频无障碍事件。
    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() = Unit

    private fun clearScheduledRefreshes() {
        refreshGeneration++
        main.removeCallbacks(refreshTask)
        main.removeCallbacks(retryTask)
        pendingRefreshes.forEach { main.removeCallbacks(it) }
        pendingRefreshes.clear()
    }

    private fun scheduleRefresh(delay: Long = 0L) {
        clearScheduledRefreshes()
        main.postDelayed(refreshTask, delay.coerceAtLeast(0L))
        // 设置变更、通知变更等外部刷新也会唤醒锁屏看护。
        scheduleWatchdog(2_500L)
    }

    private fun scheduleWatchdog(delay: Long) {
        main.removeCallbacks(watchdogTask)
        main.postDelayed(watchdogTask, delay.coerceAtLeast(500L))
    }

    /**
     * 锁屏看护：HyperOS 可能在锁屏驻留期间隐藏/移除普通应用窗口，
     * 而 SCREEN_ON 只在下一次亮屏时发送。交互式锁屏期间定期核验，
     * 如果 View 已脱离窗口则重新创建；每 30 秒从系统通知监听器同步一次快照。
     * 不持有 WakeLock，屏幕关闭时不会强制唤醒设备。
     */
    private fun runWatchdog() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        if (!prefs.getBoolean("app_enabled", true)) {
            attachRetryCount = 0
            main.removeCallbacks(retryTask)
            removeOverlay()
            return
        }

        val pm = power ?: (getSystemService(Context.POWER_SERVICE) as PowerManager).also { power = it }
        if (!pm.isInteractive) {
            // 不申请唤醒锁；设备自然休眠。下次屏幕点亮时广播会重新启动看护。
            scheduleWatchdog(15_000L)
            return
        }

        val km = keyguard ?: (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).also { keyguard = it }
        if (km.isKeyguardLocked) {
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - lastNotificationSyncAt >= 30_000L) {
                lastNotificationSyncAt = now
                HoleLightNotificationListener.refreshFromSystem()
            }
        }

        refresh()
        scheduleWatchdog(if (km.isKeyguardLocked) 4_000L else 12_000L)
    }

    /**
     * HyperOS 的屏幕点亮、Keyguard 状态和 WindowManager 就绪并非总在同一时刻。
     * 在几个时间点重新检查，避免第一次 SCREEN_ON 检查过早而永久漏掉圆环。
     */
    private fun scheduleRefreshBurst() {
        clearScheduledRefreshes()
        val generation = refreshGeneration
        val delays = longArrayOf(0L, 180L, 450L, 900L, 1600L, 2800L)
        delays.forEach { delay ->
            lateinit var task: Runnable
            task = Runnable {
                pendingRefreshes.remove(task)
                if (generation == refreshGeneration) refresh()
            }
            pendingRefreshes.add(task)
            main.postDelayed(task, delay)
        }
    }

    private fun attach(): Boolean {
        if (overlay?.isAttachedToWindow == true) return true
        // 丢失或失效的 WindowManager / View 句柄不能被当作已经显示。
        val manager = wm ?: (getSystemService(Context.WINDOW_SERVICE) as WindowManager).also { wm = it }
        val view = RingOverlayView(this)
        @Suppress("DEPRECATION")
        val showWhenLockedFlag = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                showWhenLockedFlag,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        return try {
            manager.addView(view, params)
            overlay = view
            view.refreshIcons()
            true
        } catch (_: Exception) {
            overlay = null
            false
        }
    }

    private fun removeOverlay() {
        val old = overlay ?: return
        overlay = null
        runCatching {
            if (old.isAttachedToWindow) wm?.removeViewImmediate(old)
        }
    }

    private fun scheduleAttachRetry() {
        if (attachRetryCount >= 8) return
        val delays = longArrayOf(300L, 500L, 800L, 1200L, 1800L, 2500L, 3500L, 5000L)
        val delay = delays[attachRetryCount.coerceIn(0, delays.lastIndex)]
        attachRetryCount++
        main.removeCallbacks(retryTask)
        main.postDelayed(retryTask, delay)
    }

    private fun refresh() {
        val prefs = getSharedPreferences("holelight", MODE_PRIVATE)
        if (!prefs.getBoolean("app_enabled", true)) {
            attachRetryCount = 0
            main.removeCallbacks(retryTask)
            removeOverlay()
            return
        }

        val km = keyguard ?: (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).also { keyguard = it }
        val pm = power ?: (getSystemService(Context.POWER_SERVICE) as PowerManager).also { power = it }

        // 屏幕关闭时不销毁现有窗口，也不尝试新建窗口；交给系统控制显示。
        // 屏幕点亮后由 SCREEN_ON 的多阶段检查恢复锁屏窗口。
        if (!pm.isInteractive) return

        val isLocked = km.isKeyguardLocked
        val previewEnabled = prefs.getBoolean("preview_enabled", false)
        val activePackages = prefs.getString("notification_packages", "").orEmpty()
            .split("|").filter { it.isNotBlank() }.distinct()
        val shouldShow = previewEnabled || (isLocked && activePackages.isNotEmpty())
        if (!shouldShow) {
            attachRetryCount = 0
            main.removeCallbacks(retryTask)
            removeOverlay()
            return
        }

        val current = overlay
        val healthy = current?.let { it.isAttachedToWindow && it.isShown } == true
        if (!healthy) {
            // View 可能仍有旧引用，但已从窗口树脱离；先清理旧引用再重新 addView。
            if (current != null && current.isAttachedToWindow) {
                runCatching { wm?.removeViewImmediate(current) }
            }
            overlay = null
            if (!attach()) {
                scheduleAttachRetry()
                return
            }
        }
        attachRetryCount = 0
        main.removeCallbacks(retryTask)
        overlay?.apply {
            visibility = View.VISIBLE
            alpha = 1f
            bringToFront()
            refreshIcons()
            invalidate()
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        clearScheduledRefreshes()
        main.removeCallbacks(watchdogTask)
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(screenReceiver) }
        receiverRegistered = false
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        clearScheduledRefreshes()
        main.removeCallbacks(watchdogTask)
        removeOverlay()
        if (receiverRegistered) runCatching { unregisterReceiver(screenReceiver) }
        receiverRegistered = false
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var instance: HoleLightAccessibilityService? = null
        fun requestRefresh(delay: Long = 80L) {
            instance?.scheduleRefresh(delay)
        }
    }
}
